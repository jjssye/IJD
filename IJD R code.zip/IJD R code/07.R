

library(GenomicSEM)


index <- data.table::fread("../export_index/gwasfile_info.txt")


gwas_files<-paste0("../calculating_samplesize_with_maf/",index$phenotype,".txt")


ref <- "../GenomicSEM/reference.1000G.maf.0.005.txt.gz"


phen<-index$phenotype


se.logit=rep(TRUE, length(phen))


OLS=NULL


linprob=NULL


N=NULL


betas=NULL


info.filter=0.6


maf.filter=0.01


keep.indel=FALSE


parallel=TRUE


cores = NULL


ambig=FALSE


direct.filter=FALSE


compiler::loadcmp("../sumstats.Rc", env = environment())


