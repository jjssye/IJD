
library(Fast2TWAS)
library(data.table)


inputFile=c("IJD")

for (trait in inputFile) {
  
  
  source_dir <- paste0(.libPaths()[1],"/cowplot/")
  target_dir <- getwd()
  system(paste("mv", shQuote(source_dir), shQuote(target_dir)))
  source_dir <- paste0(.libPaths()[1],"/ggplot2/")
  target_dir <- getwd()
  system(paste("mv", shQuote(source_dir), shQuote(target_dir)))
  
  
  source_dir <- "../installation/cowplot/"
  target_dir <- .libPaths()[1]
  system(paste("cp -r ", shQuote(source_dir), shQuote(target_dir)))
  source_dir <- "../installation/ggplot2/"
  target_dir <- .libPaths()[1]
  system(paste("cp -r ", shQuote(source_dir), shQuote(target_dir)))
  
  
  message("\n当前性状：",trait)
  
  eqtlenrich_file <- list.files(path = "../QTLEnrich_eQTL/result/results/", 
                                pattern = paste0("^QTLEnrich_best_eqtl_",trait,".*"),
                                full.names = T)
  
  
  if (!file.exists(eqtlenrich_file) || !file.exists(sqtlenrich_file) || length(eqtlenrich_file) != 1 || length(sqtlenrich_file) != 1) {
    stop("仔细检查QTLEnrich中的分析结果")
  }
  
  
  QTLEnrich_forest_boxplot_run(
    force=FALSE,
    qtlenrich_file1=eqtlenrich_file,
    is_forest_plot=T,
    is_bar_plot=T,
    is_box_plot=T,
    is_violin_plot=T,
    is_paired_plot=FALSE,
    label_file1="eQTL",
    identify_number_significant_tissues=49,
    significant_tissues_cutoff=0.00051,   
    gtex_tissue_names="../reference/QTLEnrich/gtex_tissue_colors_v8.txt",
    is_side_by_side=T,
    exp_label=trait,
    flag_options=NULL
  )

  unlink(paste0(.libPaths()[1],c("/cowplot/","/ggplot2/")), recursive = TRUE, force = TRUE)
  source_dir <- "./cowplot/"
  target_dir <- .libPaths()[1]
  system(paste("mv", shQuote(source_dir), shQuote(target_dir)))
  source_dir <- "./ggplot2/"
  target_dir <- .libPaths()[1]
  system(paste("mv", shQuote(source_dir), shQuote(target_dir)))
} 

