
library(Fast2TWAS)

trait="IJD"


clump_kb=10000
r2=0.1
P_th <- 5e-8

decode_dat=data.table::fread("../deCODE/decode2021_protein_annotation(clean).txt")
decode_Phenotype=unique(decode_dat$labels)

result_path="./result/"
if (!dir.exists(result_path)) {
  dir.create(result_path)
}


write(x = "", file = "mendelian_randomization_decode.log", append = F)
setwd(result_path)

for (protein in decode_Phenotype) {
  i=which(protein==decode_Phenotype)
  message("\n当前第",i,"个暴露：",protein)
  
  mr_result <- try(mendelian_randomization(exposure_dat=paste0("../../deCODE/decode_pqtl_cis_1mb_hg38/hg38_decode_pqtl_cis_1mb_",protein,".txt"),
                                           outcome_dat = paste0("../../",metafile),#路径要注意
                                           pval = P_th,
                                           exposure_trait = protein,
                                           outcome_trait = trait,
                                           clump_local = T,
                                           clump_kb = clump_kb,
                                           r2 = r2,
                                           bfile = "../../1000Gv3/EUR",
                                           method_list = subset(TwoSampleMR::mr_method_list(), use_by_default)$obj,
                                           F_method = 2, #利用beta^2/se^2计算
                                           Ffilter = 10,
                                           mr_report = FALSE,
                                           plot = FALSE), silent =T)
  
  if ("try-error" %in% class(mr_result)) {
    line=paste0(protein," 未能成功与",metafile,"进行孟德尔随机化，直接跳过")
    message(line)
    write(x = line, file = "../mendelian_randomization_decode.log", append = T)
    next}
}


