
library(Fast2TWAS)
options(timeout = 1000)


trait="IJD"


IVW_method="Fixed"


wind_size=1000000
type1="quant"         
type2="cc"            
case_pro1=NULL        
case_pro2=0.0163837  
width = 7             
height = 7            


IVW_Wald_ratio_sig=data.table::fread(paste0("../fdr_mendelian_randomization_decode/",trait,"_IVW_Wald_ratio_sig_MR_result.txt"))

coloc_path="./result/"
if (!dir.exists(coloc_path)) {
  dir.create(coloc_path)
}


for (i in 1:length(IVW_Wald_ratio_sig$gene)) {
  gene=gsub("_","-",IVW_Wald_ratio_sig$gene[i]) 
  message("\n当前第",i,"个基因: ",gene)
  message("当前第",i,"个暴露:",IVW_Wald_ratio_sig$exposure[i])
  print(IVW_Wald_ratio_sig[i,])
  coloc_local_gwas2gwas(gwasfile=c(paste0("../deCODE/decode_pqtl_cis_1mb_hg38/hg38_decode_pqtl_cis_1mb_",IVW_Wald_ratio_sig$exposure[i],".txt"),
                                   metafile),
                        wind_size = wind_size,
                        gene = gene,
                        bfile = "../1000Gv3/EUR",
                        plink_bin = friendlypostGWASsoft::plink_binary(),
                        outfile = paste0(coloc_path,gene,"_",IVW_Wald_ratio_sig$exposure[i],"_",wind_size/1000,"kb.local"),
                        width = width,
                        height = height,
                        build = 38,
                        EUR = "EUR",
                        plot_locuscompare = TRUE,
                        plot_locuscompare_title1="pQTL",
                        plot_locuscompare_title2="GWAS",
                        plot_gassocplot2 = TRUE,
                        type1 = type1,
                        type2 = type2,
                        trait_name1 = gene,
                        trait_name2 = trait,
                        case_pro1 = case_pro1,
                        case_pro2 = case_pro2)
}


all_coloc=data.frame()
for (i in 1:length(IVW_Wald_ratio_sig$gene)) {
  gene=gsub("_","-",IVW_Wald_ratio_sig$gene[i]) 
  message("\n当前第",i,"个基因: ",gene)
  print(IVW_Wald_ratio_sig[i,])
  
  
  data=data.table::fread(paste0(coloc_path,gene,"_",IVW_Wald_ratio_sig$exposure[i],"_",wind_size/1000,"kb.local.coloc_summary.txt"))
  data$exposure=IVW_Wald_ratio_sig$exposure[i]
  data$gene=gene
  all_coloc=rbind(all_coloc,data)
  
}



data.table::fwrite(all_coloc_all,
                   file =paste0(trait,"_decode_coloc.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


