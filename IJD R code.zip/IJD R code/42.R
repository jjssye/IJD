
library(Fast2TWAS)
library(data.table)


inputFile=c("IJD")


tissue_data <-fread("..//gtex_tissue_names.txt",header = F)  
for (trait in inputFile) {
  for (tissue in tissue_data$V1) {
  
  message("\n当前性状：",trait,"; 当前第",which(tissue == tissue_data$V1),"个组织：",tissue)  
  
  key <- paste0(trait,"_",tissue)
  
  qtl_file <- list.files(path = "../output_files/", 
                         pattern = paste0("^QTLEnrich_significant.*",key),
                         full.names = T)
  pvalue_null_matrix  <- list.files(path = "../output_files/", 
                                    pattern = paste0("^QTLEnrich_matched_null.*",key),
                                    full.names = T)
  
  
  if (!file.exists(qtl_file) || !file.exists(pvalue_null_matrix) || length(qtl_file) != 1 || length(pvalue_null_matrix) != 1) {
    stop("仔细检查QTLEnrich中的分析结果")
  }
  
  
  QTLEnrich_qqplot_run(
    qtl_file=qtl_file,
    gwas_file=paste0("../hg19Tohg38/",trait,"_hg38_qc_QTLEnrich.txt"),
    pvalue_null_matrix=pvalue_null_matrix,
    is_gwas_background=T,
    is_matched_null_background=T,
    num_permutations=100,
    is_confidence_interval=T,
    upper_bound_ci=97.5,
    lower_bound_ci=2.5,
    upper_bound_clip=0,
    trait_label=trait,
    qtl_type="eQTLs",
    tissue_label=tissue,
    is_show_title=TRUE,
    qqplot_title=paste0(trait," GWAS"),
    flag_options=NULL,
    x_inches=12,
    y_inches=10,
    dpi=1000,
    is_help=F,
    force=F)

  }
}

