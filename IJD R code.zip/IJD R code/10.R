


library(Fast2TWAS)
library(data.table)


load("../PSYCH_factor_with_N_hat.RData")

print(head(PSYCH_factor))


data <- gwas2format(
        gwas_dat = PSYCH_factor,
        chr_col = "CHR",
        pos_col = "BP",
        snp_col = "SNP",
        effect_allele_col = "A1",
        other_allele_col = "A2",
        eaf_col = "MAF",
        beta_col = "est",
        se_col = "se_c",
        pval_col = "Pval_Estimate",
        log_pval = FALSE,
        ncase_col = "ncase",
        ncontrol_col = "ncontrol",
        samplesize_col = "N_hat"
        )


print(data)


fwrite(data,
       file = "fuma_PSYCH_factor.txt",
       sep = "\t")

fwrite(data,
       file = "fuma_PSYCH_factor.gz",
       sep = "\t")


----------------------------------
Fast2TWAS::ldsc_format(gwasfile="fuma_PSYCH_factor.txt",
                       outname = "fuma_PSYCH_factor",
                       flag_options = "--chunksize 500000",
                       merge_alleles = "../ldsc/w_hm3.snplist",
                       force = F) 


inputgwas=paste0("./result/fuma_PSYCH_factor.sumstats.gz")
Fast2TWAS::ldsc_h2(gwasfile=inputgwas,
                   LD_ref_dir = "../ldsc/eur_w_ld_chr/",
                   flag_options = NULL,
                   outname = "fuma_PSYCH_factor_ldsc_h2",
                   force = F)


