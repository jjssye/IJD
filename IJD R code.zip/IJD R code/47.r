
library(Fast2TWAS)
library(Seurat)
library(celldex)
library(GSVA)
library(GSEABase)
library(harmony)
library(plyr)
library(ggalluvial)
library(harmony)
library(tidydr)
library(tidyverse)
library(Matrix)
library(stringr)
library(dplyr)
library(patchwork)
library(SingleR)
library(clustree)
library(cowplot)
library(SCpubr)


mmRNA <- readRDS("final_combined_IJD.rds")


dir.create("QC_Plots", showWarnings = FALSE)
dir.create("Gene_Analysis", showWarnings = FALSE)
dir.create("Dimension_Reduction", showWarnings = FALSE)


mmRNA[["percent.mt"]] <- PercentageFeatureSet(mmRNA, pattern = "^MT-")


HB_genes <- c("HBA1", "HBA2", "HBB", "HBD", "HBE1", "HBG1", "HBG2", "HBM", "HBQ1", "HBZ")
valid_HB_genes <- intersect(HB_genes, rownames(mmRNA))

mmRNA[["percent.HB"]] <- PercentageFeatureSet(mmRNA, features = valid_HB_genes)


qc_plots <- VlnPlot(mmRNA, 
                    features = c("nFeature_RNA", "nCount_RNA", "percent.mt", "percent.HB"), 
                    group.by = "group",  # 关键参数：按group列分组
                    ncol = 4, 
                    pt.size = 0.1)

ggsave("QC_Plots/vln_plot_before_qc.pdf", plot = qc_plots, width = 12, height = 6)


mmRNA <- subset(mmRNA, 
                subset = nCount_RNA >= 1000 & 
                  nFeature_RNA > 200 & 
                  nFeature_RNA < 5000 & 
                  percent.mt <= 15 & 
                  percent.HB <= 3)


qc_plots_after <- VlnPlot(mmRNA, features = c("nFeature_RNA", "nCount_RNA", "percent.mt", "percent.HB"), 
                          ncol = 4, pt.size = 0.1, group.by = "group")

ggsave("QC_Plots/vln_plot_after_qc.pdf", plot = qc_plots_after, width = 12, height = 6)


top10_var <- head(VariableFeatures(mmRNA), 10)
var_plot <- VariableFeaturePlot(mmRNA, pt.size = 1.5)
labeled_plot <- LabelPoints(plot = var_plot, points = top10_var, repel = TRUE)

ggsave("Gene_Analysis/top_variable_genes.pdf", plot = labeled_plot, width = 10, height = 8)

mmRNA <- ScaleData(mmRNA, features = VariableFeatures(mmRNA))


mmRNA <- RunTSNE(mmRNA, dims = 1:30)


pca_heatmaps <- DimHeatmap(mmRNA, 
                           dims = 1:10, 
                           nfeatures = 20, 
                           cells = 500, 
                           balanced = TRUE,
                           fast = FALSE)
ggsave("Dimension_Reduction/pca_heatmaps.pdf", plot = pca_heatmaps, width = 14, height = 16)


elbow_plot <- ElbowPlot(mmRNA, ndims = 50) +
  geom_vline(xintercept = 15, linetype = "dashed", color = "red") +
  labs(title = "PCA Elbow Plot", 
       subtitle = "Variance explained by principal components",
       caption = "Red line indicates suggested cutoff (PC15)")
ggsave("Dimension_Reduction/elbow_plot.pdf", plot = elbow_plot, width = 8, height = 6)



group_colors <- distinctColorPalette(length(unique(mmRNA$group)))
group_tsne <- DimPlot(mmRNA, 
                      reduction = "tsne",
                      group.by = "group",
                      cols = group_colors) +
  theme_minimal() +
  ggtitle("Group-wise t-SNE Projection")
ggsave("Dimension_Reduction/group_tsne.pdf", plot = group_tsne, width = 10, height = 8)


group_colors <- distinctColorPalette(length(unique(mmRNA$group)))
group_pca <- DimPlot(mmRNA, 
                      reduction = "pca",
                      group.by = "group",
                      cols = group_colors) +
  theme_minimal() +
  ggtitle("Group-wise pca Projection")
ggsave("Dimension_Reduction/group_pca.pdf", plot = group_tsne, width = 10, height = 8)

saveRDS(mmRNA, "mmRNA.rds")


mmRNA_harmony <- RunHarmony(mmRNA, 
                            group.by.vars = "orig.ident",
                            theta = 2, 
                            lambda = 1,
                            verbose = TRUE)


saveRDS(mmRNA_harmony, "harmony_corrected_seurat.rds")


mmRNA_harmony <- FindVariableFeatures(
  mmRNA_harmony,
  selection.method = "vst",
  nfeatures = 2000
)

top10_harmony <- head(VariableFeatures(mmRNA_harmony), 10)
cat("校正后Top 10高变基因:\n")
print(top10_harmony)


var_plot <- VariableFeaturePlot(mmRNA_harmony) +
  theme_minimal() +
  labs(title = "Harmony校正后高变基因")


labeled_plot <- LabelPoints(
  plot = var_plot,
  points = top10_harmony,
  repel = TRUE,
  size = 4
) 

ggsave("harmony_variable_genes.pdf", 
       plot = labeled_plot, 
       width = 10, height = 8)
