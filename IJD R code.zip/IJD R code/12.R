
library(tidyverse)
library(Fast2TWAS)
library(data.table)


dat_leadSNPs <- fread(paste0(FUMA_path,"/leadSNPs.txt"))
head(dat_leadSNPs)


load("../common_factor_gwas/PSYCH_factor_with_N_hat.RData")
head(PSYCH_factor)


dat_snps=data.table::fread(paste0(FUMA_path,"/snps.txt"))
head(dat_snps)


df12 <- merge(dat_leadSNPs, PSYCH_factor, by.x = "rsID",by.y = "SNP")
df123 <- merge(df12, dat_snps, by= "rsID")
head(df123)


name <- c(
  "No",
  "rsID",
  "GenomicLocus.x",
  "CHR",
  "BP",
  "nIndSigSNPs",
  "IndSigSNPs" ,
  "non_effect_allele",
  "effect_allele",
  "MAF.x",
  "p",
  "beta",
  "se",
  "nearestGene",
  "dist",
  "func",
  "CADD",
  "RDB",
  "minChrState",
  "commonChrState",
  "Q",
  "Q_df",
  "Q_pval")


df123_final <- df123 %>%  select(name)
colnames(df123_final)[colnames(df123_final) == "GenomicLocus.x"] <- "GenomicLocus"
colnames(df123_final)[colnames(df123_final) == "MAF.x"] <- "MAF"
colnames(df123_final)[colnames(df123_final) == "No"] <- "Novel"
df123_final <- df123_final[order(df123_final$No),]
head(df123_final)


fwrite(df123_final,
       file = "pre_STable6.txt",
       sep = "\t")


