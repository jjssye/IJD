


library(Matrix)
library(stats)


load("../ld-score_regression/LDSCoutput.RData")
anthro <- LDSCoutput


Ssmooth<-as.matrix((nearPD(anthro$S, corr = FALSE))$mat)


EFA_factor1<-factanal(covmat = Ssmooth, factors = 1, rotation = "promax")


EFA_factor2<-factanal(covmat = Ssmooth, factors = 2, rotation = "promax")


EFA_factor2_psych <- fa(Ssmooth, nfactors = 2, rotate = "promax", fm = "ml")
print(EFA_factor2_psych)



print(EFA_factor1)
print(EFA_factor2)


save(EFA_factor1,EFA_factor2,file = "STable3.txt.RData")

save(EFA_factor1,EFA_factor2_psych,file = "STable3.txt.RData")


