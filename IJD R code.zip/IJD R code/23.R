
library(Fast2TWAS)


ldsc_partitioned_heritability(gwasfile="../result/fuma_PSYCH_factor.sumstats.gz",
                              w_ld_chr = "../ldsc/1000G_Phase3_weights_hm3_no_MHC/weights.hm3_noMHC.",
                              ref_ld_chr = "../ldsc/baseline_v1.1_thin_annot/baseline.",
                              frqfile_chr = "../ldsc/1000G_Phase3_frq/1000G.EUR.QC.",
                              flag_options = NULL,
                              outname = "PSYCH_factor_partitioned_heritability",
                              force = FALSE)


S_LDSC_data=fread("result/PSYCH_factor_partitioned_heritability.results")

S_LDSC_data$FDR=p.adjust(p = S_LDSC_data$Enrichment_p, method = "fdr")


fwrite(S_LDSC_data,
       file = "STable18.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)


