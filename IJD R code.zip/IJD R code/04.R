


library(GenomicSEM)


index <- data.table::fread("../gwasfile_info.txt")



gwas_files<-paste0("../munge_gwas/",index$phenotype,".sumstats.gz")


sample.prev <- c()
for (file in index$filename) {
  
  casecontrol <- ifelse(!is.na(index$case[which(file==index$filename)]) & !is.na(index$controls[which(file==index$filename)]),TRUE,FALSE)
  ismeta <- index$ismeta[which(file==index$filename)]
  
  
  if (casecontrol) {
    if (ismeta) {
      single_sample.prev <- 0.5
    }else{
      
      single_sample.prev <- round(index$case[which(file==index$filename)]/(index$case[which(file==index$filename)]+index$controls[which(file==index$filename)]), 4)
    }
    if (single_sample.prev < 0 | single_sample.prev > 1) {
      stop("sample.prev计算错误，请确认数据后重新分析")
    }
  }else{
    single_sample.prev <- NA
  }
  sample.prev <- c(sample.prev,single_sample.prev)
}
print(sample.prev)

population.prev<-index$population.prev
print(population.prev)

ld<-"../GenomicSEM/eur_w_ld_chr/"


wld<-"../GenomicSEM/eur_w_ld_chr/"


phen<-index$phenotype
print(phen)


compiler::loadcmp("../ldsc.Rc", env = environment())

