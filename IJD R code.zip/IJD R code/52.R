



library(data.table)
library(dplyr)
library(ggplot2)
library(igraph)
library(ggraph)
library(tidyr)
library(scales)
library(gridExtra)
library(RColorBrewer)


pqtl_genes <- c("ABO", "AIF1", "APOF", "ICAM5", "IL6R", "MICA", "SH3GLB2")


decode_beta <- c(-0.012277728, 2.247313395, -0.084460567, -0.030469611, 
                 0.017764027, 0.233971994, -0.038646715)


ukb_beta <- c(-0.020234919, 1.658499971, -0.101691108, -0.028229600, 
              0.013858744, 0.251467482, -0.052668684)


cytokines <- c("G_CSF", "IL_2RA")
cytokine_beta <- c(-0.057025162, -0.022453634)


immune_cells <- c(
  "HLA DR on CD14- CD16+ monocyte",
  "CD64 on monocyte",
  "SSC-A on plasmacytoid DC",
  "CD45RA+ CD28- CD8br %T cell",
  "CD86+ myeloid DC %DC",
  "SSC-A on HLA DR+ NK",
  "CD33br HLA DR+ AC",
  "CD27 on CD20-",
  "CD14- CD16+ monocyte %monocyte",
  "Activated Treg %CD4 Treg",
  "CD28 on CD4 Treg",
  "CD27 on IgD- CD38dim",
  "CD86 on granulocyte",
  "CD64 on CD14+ CD16+ monocyte",
  "CD19 on IgD+ CD38- unsw mem",
  "PB/PC AC",
  "FSC-A on HLA DR+ CD4+",
  "T/B",
  "CD16+ monocyte %monocyte",
  "IgD+ CD24- AC",
  "CD19 on PB/PC",
  "HLA DR+ CD4+ %lymphocyte",
  "FSC-A on HLA DR+ NK",
  "Naive DN (CD4-CD8-) AC"
)

immune_beta <- c(
  -0.034066299, -0.016746394, -0.02802267, 0.003396045, 0.017284797,
  -0.018010365, 0.018930073, 0.034738994, -0.02434847, -0.022973826,
  -0.02012911, -0.011663041, 0.026546468, -0.013024669, -0.016987628,
  0.025608507, -0.026116146, 0.016826779, -0.020904129, 0.024105833,
  0.024569776, 0.02388002, -0.014376068, -0.032615966
)


eqtl_coloc_genes <- c(
  "ACOT13", "ACTB", "CCHCR1", "FAM65B", "FKBP5", "HCP5", "HLA-C", 
  "HLA-DRA", "IER3", "ITPR3", "MDC1", "NOTCH4", "POU5F1", "SRPK1", 
  "TNRC18", "ZKSCAN3"
)


pqtl_comparison <- data.frame(
  Gene = pqtl_genes,
  deCODE_Beta = decode_beta,
  UKB_Beta = ukb_beta,
  stringsAsFactors = FALSE
) %>%
  mutate(
    Mean_Beta = (deCODE_Beta + UKB_Beta) / 2,
    Effect = ifelse(Mean_Beta > 0, "Risk", "Protective"),
    Effect_Direction = ifelse(sign(deCODE_Beta) == sign(UKB_Beta), 
                              "Consistent", "Inconsistent"),
    Strength = case_when(
      abs(Mean_Beta) > 1.0 ~ "Extremely Strong",
      abs(Mean_Beta) > 0.2 ~ "Strong",
      abs(Mean_Beta) > 0.05 ~ "Moderate",
      TRUE ~ "Weak"
    )
  )


immune_df <- data.frame(
  Cell = immune_cells,
  Beta = immune_beta,
  stringsAsFactors = FALSE
) %>%
  mutate(
    Effect = ifelse(Beta > 0, "Risk", "Protective"),
    Type = "Immune Cell"
  )


cytokine_df <- data.frame(
  Factor = cytokines,
  Beta = cytokine_beta,
  stringsAsFactors = FALSE
) %>%
  mutate(
    Effect = ifelse(Beta > 0, "Risk", "Protective"),
    Type = "Cytokine"
  )


eqtl_df <- data.frame(
  Gene = eqtl_coloc_genes,
  Type = "eQTL Gene",
  Effect = "Risk/Protective",  # Placeholder
  stringsAsFactors = FALSE
)


fig1a <- ggplot(pqtl_comparison, aes(x = deCODE_Beta, y = UKB_Beta, label = Gene)) +
  geom_point(aes(color = Effect, size = abs(Mean_Beta)), alpha = 0.8) +
  geom_text(vjust = -0.8, hjust = 0.5, size = 3.5) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "gray50", size = 1) +
  geom_hline(yintercept = 0, linetype = "dotted", color = "gray") +
  geom_vline(xintercept = 0, linetype = "dotted", color = "gray") +
  scale_color_manual(values = c("Risk" = "#E41A1C", "Protective" = "#377EB8")) +
  scale_size_continuous(range = c(3, 12), guide = "none") +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    panel.grid.minor = element_blank()
  ) +
  labs(
    title = "Cross-Database Validation of pQTL MR Results",
    subtitle = "deCODE vs UKB-PPP (n_deCODE > 30,000; n_UKB = 54,219)",
    x = "deCODE Beta Coefficient",
    y = "UKB-PPP Beta Coefficient",
    color = "Effect Direction"
  ) +
  xlim(-0.2, 2.5) + ylim(-0.2, 2.5)


pqtl_plot_data <- pqtl_comparison %>%
  tidyr::pivot_longer(cols = c(deCODE_Beta, UKB_Beta), 
                      names_to = "Database", 
                      values_to = "Beta") %>%
  mutate(Database = gsub("_Beta", "", Database))

fig1b <- ggplot(pqtl_plot_data, aes(x = reorder(Gene, -abs(Mean_Beta)), 
                                    y = Beta, 
                                    fill = Database)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_fill_manual(values = c("deCODE" = "#E41A1C", "UKB" = "#377EB8")) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    plot.title = element_text(hjust = 0.5, face = "bold")
  ) +
  labs(
    title = "pQTL Effect Sizes: deCODE vs UKB-PPP",
    x = "",
    y = "Beta Coefficient (IVW)",
    fill = "Database"
  )


fig1 <- grid.arrange(fig1a, fig1b, ncol = 2, widths = c(1, 1.2))
ggsave("Figure1_pQTL_cross_database.pdf", fig1, width = 14, height = 6)


evidence_summary <- rbind(
  pqtl_comparison %>% select(Gene, Mean_Beta, Effect, Strength) %>% 
    mutate(Layer = "Protein (pQTL)"),
  
  cytokine_df %>% 
    select(Factor, Beta, Effect) %>% 
    rename(Gene = Factor, Mean_Beta = Beta) %>% 
    mutate(Strength = ifelse(abs(Mean_Beta) > 0.05, "Moderate", "Weak"),
           Layer = "Cytokine"),
  
  immune_df %>% 
    slice_max(abs(Beta), n = 8) %>% 
    select(Cell, Beta, Effect) %>% 
    rename(Gene = Cell, Mean_Beta = Beta) %>% 
    mutate(Strength = ifelse(abs(Mean_Beta) > 0.03, "Strong",
                             ifelse(abs(Mean_Beta) > 0.02, "Moderate", "Weak")),
           Layer = "Immune Cell")
)


fig2 <- ggplot(evidence_summary, aes(x = Layer, y = reorder(Gene, -abs(Mean_Beta)))) +
  geom_point(aes(size = abs(Mean_Beta), color = Effect), alpha = 0.7) +
  scale_color_manual(
    values = c("Risk" = "#E41A1C", "Protective" = "#377EB8"),
    name = "Effect Direction"
  ) +
  scale_size_continuous(
    range = c(2, 12),
    breaks = c(0.02, 0.05, 0.2, 1, 2),
    labels = c("0.02", "0.05", "0.2", "1.0", "2.0"),
    name = "Effect Size (|Beta|)"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 0.5, face = "bold", size = 11),
    axis.text.y = element_text(size = 9),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 10),
    legend.position = "right",
    legend.box = "vertical",
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_line(color = "gray90", size = 0.5)
  ) +
  labs(
    title = "Multi-Omics Evidence for IJD Association",
    subtitle = "Bubble size represents effect magnitude | AIF1 shows strongest risk effect",
    x = "Biological Layer",
    y = ""
  )

ggsave("Figure2_multi_layer_evidence.pdf", fig2, width = 10, height = 10)
print(fig2)


immune_heatmap_data <- immune_df %>%
  mutate(
    Cell_Group = case_when(
      grepl("monocyte", Cell, ignore.case = TRUE) ~ "Monocyte",
      grepl("T cell|Treg|CD4|CD8", Cell, ignore.case = TRUE) ~ "T Cell",
      grepl("DC|dendritic", Cell, ignore.case = TRUE) ~ "Dendritic Cell",
      grepl("NK", Cell, ignore.case = TRUE) ~ "NK Cell",
      grepl("B cell|CD19|IgD", Cell, ignore.case = TRUE) ~ "B Cell",
      TRUE ~ "Other"
    ),
    Effect_Label = ifelse(Beta > 0, "Risk Factor", "Protective Factor")
  ) %>%
  arrange(desc(abs(Beta)))

fig3 <- ggplot(immune_heatmap_data, aes(x = Cell_Group, y = reorder(Cell, Beta))) +
  geom_tile(aes(fill = Beta), color = "white", size = 0.5) +
  scale_fill_gradient2(
    low = "#377EB8", mid = "white", high = "#E41A1C",
    midpoint = 0, 
    name = expression(beta ~ "Coefficient"),
    breaks = c(-0.04, -0.02, 0, 0.02, 0.04),
    labels = c("-0.04", "-0.02", "0", "0.02", "0.04")
  ) +
  theme_minimal(base_size = 10) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold"),
    axis.text.y = element_text(size = 7.5),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 10),
    panel.grid = element_blank(),
    legend.position = "right"
  ) +
  labs(
    title = "Immune Cell Phenotypes Associated with IJD",
    subtitle = "Red = Risk factor | Blue = Protective factor | Color intensity = Effect magnitude",
    x = "Cell Type Group",
    y = ""
  )


ggsave("Figure3_immune_cell_landscape.pdf", fig3, width = 10, height = 12)
print(fig3)


network_nodes <- rbind(
  pqtl_comparison %>% 
    select(Gene, Mean_Beta, Effect, Strength) %>%
    mutate(Level = "Protein", Size = abs(Mean_Beta) * 3 + 2),
  
  cytokine_df %>%
    select(Factor, Beta, Effect) %>%
    rename(Gene = Factor, Mean_Beta = Beta) %>%
    mutate(Level = "Cytokine", Strength = "Moderate", 
           Size = abs(Mean_Beta) * 10 + 1),
  
  immune_df %>%
    filter(abs(Beta) > 0.02) %>%
    select(Cell, Beta, Effect) %>%
    rename(Gene = Cell, Mean_Beta = Beta) %>%
    mutate(Level = "Immune Cell", Strength = "Moderate",
           Size = abs(Mean_Beta) * 20 + 1)
)


ijd_node <- data.frame(
  Gene = "IJD",
  Mean_Beta = 0,
  Effect = NA,
  Strength = "Disease",
  Level = "Disease",
  Size = 15
)

network_nodes <- rbind(network_nodes, ijd_node)


existing_immune_cells <- immune_df$Cell


edges <- data.frame(
  from = c(
    
    rep("AIF1", 4),
    
    rep("MICA", 3),
    
    rep("IL6R", 2),
    
    "AIF1", "MICA", "G_CSF", "IL_2RA"
  ),
  to = c(
    
    "CD64 on monocyte", 
    "HLA DR on CD14- CD16+ monocyte",
    "CD86+ myeloid DC %DC", 
    "Activated Treg %CD4 Treg",
    
    "HLA DR on CD14- CD16+ monocyte", 
    "CD86+ myeloid DC %DC",
    "HLA DR+ CD4+ %lymphocyte",
   
    "HLA DR+ CD4+ %lymphocyte", 
    "CD64 on monocyte",
    
    "HLA DR+ CD4+ %lymphocyte",
    "CD86+ myeloid DC %DC",
    "HLA DR+ CD4+ %lymphocyte",
    "Activated Treg %CD4 Treg"
  ),
  relationship = c(
    "regulates", "regulates", "regulates", "regulates",
    "regulates", "regulates", "regulates",
    "regulates", "regulates", 
    "regulates", "regulates", "activates", "activates"
  ),
  direction = c(
    rep("negative", 4), 
    rep("positive", 3), 
    rep("positive", 2),
    "positive", "positive", "negative", "negative"
  ),
  stringsAsFactors = FALSE
)


valid_nodes <- network_nodes$Gene
edges_filtered <- edges[edges$from %in% valid_nodes & edges$to %in% valid_nodes, ]


ijd_edges <- data.frame(
  from = c(network_nodes$Gene[network_nodes$Level %in% c("Immune Cell", "Cytokine")]),
  to = rep("IJD", sum(network_nodes$Level %in% c("Immune Cell", "Cytokine"))),
  relationship = rep("associated_with", sum(network_nodes$Level %in% c("Immune Cell", "Cytokine"))),
  direction = rep("mixed", sum(network_nodes$Level %in% c("Immune Cell", "Cytokine"))),
  stringsAsFactors = FALSE
)


edges_final <- rbind(edges_filtered, ijd_edges)


graph <- graph_from_data_frame(edges_final, vertices = network_nodes, directed = FALSE)


V(graph)$color <- case_when(
  V(graph)$Level == "Protein" & V(graph)$Effect == "Risk" ~ "#E41A1C",
  V(graph)$Level == "Protein" & V(graph)$Effect == "Protective" ~ "#377EB8",
  V(graph)$Level == "Cytokine" ~ "#4DAF4A",
  V(graph)$Level == "Immune Cell" & V(graph)$Effect == "Risk" ~ "#FF8C00",
  V(graph)$Level == "Immune Cell" & V(graph)$Effect == "Protective" ~ "#6A3D9A",
  V(graph)$Level == "Disease" ~ "#000000",
  TRUE ~ "gray70"
)


V(graph)$size <- ifelse(V(graph)$Level == "Disease", 15,
                        ifelse(V(graph)$Level == "Protein", 
                               abs(V(graph)$Mean_Beta) * 8 + 5,
                               ifelse(V(graph)$Level == "Cytokine", 8, 6)))


set.seed(123)
fig4 <- ggraph(graph, layout = "fr") +
  geom_edge_link(aes(color = direction, 
                     width = as.factor(relationship)), 
                 alpha = 0.5, 
                 show.legend = FALSE) +
  geom_node_point(aes(size = size, fill = color), 
                  shape = 21, 
                  color = "black", 
                  alpha = 0.9) +
  geom_node_text(aes(label = ifelse(Level %in% c("Protein", "Cytokine", "Disease"), 
                                    name, 
                                    ifelse(abs(Mean_Beta) > 0.025, name, ""))), 
                 repel = TRUE, 
                 size = 3, 
                 max.overlaps = 30) +
  scale_edge_color_manual(values = c("positive" = "#E41A1C", 
                                     "negative" = "#377EB8",
                                     "mixed" = "gray50")) +
  scale_fill_identity() +
  scale_size_continuous(range = c(3, 12), guide = "none") +
  theme_void() +
  labs(
    title = "Integrated Causal Network of Inflammatory Joint Disease",
    subtitle = "Red edges: positive association | Blue edges: negative association | Node size: effect magnitude"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 10)
  )


ggsave("Figure4_integrated_network.pdf", fig4, width = 14, height = 12)
print(fig4)


priority_data <- pqtl_comparison %>%
  mutate(
    Priority = case_when(
      Gene == "AIF1" ~ 1,
      Gene == "MICA" ~ 2,
      Gene == "IL6R" ~ 3,
      TRUE ~ 4
    ),
    Therapeutic_Potential = case_when(
      Gene == "AIF1" ~ "Highest Priority",
      Gene == "MICA" ~ "High Priority",
      Gene == "IL6R" ~ "Medium Priority (Existing Drugs)",
      TRUE ~ "Lower Priority"
    )
  ) %>%
  arrange(Priority)

fig5 <- ggplot(priority_data, aes(x = reorder(Gene, -Mean_Beta), 
                                  y = Mean_Beta, 
                                  fill = Therapeutic_Potential)) +
  geom_bar(stat = "identity", width = 0.7) +
  geom_errorbar(aes(ymin = UKB_Beta, ymax = deCODE_Beta), width = 0.2, color = "gray30") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", size = 0.5) +
  scale_fill_manual(values = c("Highest Priority" = "#E41A1C",
                               "High Priority" = "#FF8C00",
                               "Medium Priority (Existing Drugs)" = "#4DAF4A",
                               "Lower Priority" = "#377EB8")) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, face = "bold", size = 11),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 10),
    legend.position = "bottom",
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 9)
  ) +
  labs(
    title = "Therapeutic Target Prioritization for IJD",
    subtitle = "Bars show mean effect size; error bars show deCODE to UKB-PPP range",
    x = "",
    y = expression("Mean " * beta * " Coefficient (Risk ← → Protective)"),
    fill = "Therapeutic Priority"
  ) +
  annotate("text", x = 1, y = 2.2, label = "AIF1: Master Regulator", 
           color = "#E41A1C", fontface = "bold", size = 4.5)


ggsave("Figure5_therapeutic_priorities.pdf", fig5, width = 10, height = 6)
print(fig5)




