
library(Seurat)
library(dplyr)
library(ggplot2)
library(ggrepel)
library(limma)
library(RColorBrewer)


set.seed(123456)

sc_data <- readRDS("After_auto_anno_mmRNA_harmony.rds")


tissue_name <- "PBMC"  


control_samples <- c("singlecellhc1","singlecellhc2")    

treatment_samples <- c("singlecellas1","singlecellas2","singlecellas3","singlecellas4",
                       "singlecellpas1","singlecellpas2","singlecellra1","singlecellra2") 


group_names <- c("Control", "Treatment")  


min_cells_per_group <- 3      
min_pct <- 0.1                
logfc_threshold <- 0.5        
pval_threshold <- 0.05        
fdr_method <- "fdr"           
output_dir <- "DE_Results"
dir.create(output_dir, showWarnings = FALSE)


sc_data@meta.data$group <- ifelse(
  sc_data@meta.data$orig.ident %in% control_samples, group_names[1],
  ifelse(sc_data@meta.data$orig.ident %in% treatment_samples, group_names[2], NA)
)


cat("\n=== Group Statistics ===\n")
group_stats <- table(sc_data@meta.data$orig.ident, sc_data@meta.data$group)
print(group_stats)
write.csv(group_stats, file.path(output_dir, "sample_group_stats.csv"))


run_de_analysis <- function(sc_obj, cell_type, group1, group2, tissue,
                            min_cells = 3, logfc_threshold = 0.5,
                            pval_threshold = 0.05, min_pct = 0.1,
                            fdr_method = "BH") {
  
  
  sc_obj$celltype.group <- paste(sc_obj$Celltype, sc_obj$group, sep = "_")
  Idents(sc_obj) <- "celltype.group"
  
  group1_id <- paste0(cell_type, "_", group1)
  group2_id <- paste0(cell_type, "_", group2)
  
  n_group1 <- sum(sc_obj$celltype.group == group1_id, na.rm = TRUE)
  n_group2 <- sum(sc_obj$celltype.group == group2_id, na.rm = TRUE)
  
  if (n_group1 < min_cells | n_group2 < min_cells) {
    message(paste("Skipping", cell_type, ": ", group1, "cells =", n_group1, 
                  ", ", group2, "cells =", n_group2))
    return(NULL)
  }
  
  markers <- FindMarkers(
    object = sc_obj,
    ident.1 = group1_id,
    ident.2 = group2_id,
    test.use = "wilcox",
    logfc.threshold = 0,
    min.pct = min_pct,
    verbose = FALSE
  )
  
  markers$p_val_adj <- p.adjust(markers$p_val, method = fdr_method)
  markers$gene <- rownames(markers)
  markers$cell_type <- cell_type
  markers$comparison <- paste(group1, "vs", group2)
  markers$tissue <- tissue
  
  markers$direction <- ifelse(
    markers$p_val_adj < pval_threshold & markers$avg_log2FC > logfc_threshold, "+",
    ifelse(markers$p_val_adj < pval_threshold & markers$avg_log2FC < -logfc_threshold, "-", "ns")
  )
  
  markers$significance <- ifelse(
    markers$direction != "ns", 
    paste("logFC >", abs(logfc_threshold), "& FDR <", pval_threshold),
    "ns"
  )
  
  markers <- markers %>%
    select(tissue, gene, p_val, avg_log2FC, pct.1, pct.2, p_val_adj, cell_type, 
           comparison, direction, significance, everything())
  
  return(markers)
}



cell_types <- unique(sc_data$Celltype)
all_results <- list()


for (cell_type in cell_types) {
  cat("\nAnalyzing:", cell_type, "\n")
  
  markers <- run_de_analysis(
    sc_obj = sc_data,
    cell_type = cell_type,
    group1 = group_names[2],
    group2 = group_names[1],
    tissue = tissue_name,
    min_cells = min_cells_per_group,
    logfc_threshold = logfc_threshold,
    pval_threshold = pval_threshold,
    min_pct = min_pct,
    fdr_method = fdr_method
  )
  
  if (!is.null(markers)) {
    filename <- paste0(tissue_name, "_", cell_type, "_", group_names[2], "_vs_", group_names[1], "_DE.csv")
    write.csv(markers, file.path(output_dir, filename), row.names = FALSE)
    
    all_results[[cell_type]] <- markers
    
    cat("==> Analysis complete. Results saved to:", filename, "\n")
    
    sig_up <- sum(markers$direction == "+")
    sig_down <- sum(markers$direction == "-")
    cat("==> Upregulated genes:", sig_up, "| Downregulated genes:", sig_down, "\n")
  }
}

if (length(all_results) > 0) {
  combined_results <- do.call(rbind, all_results)
  write.csv(combined_results, file.path(output_dir, "all_celltypes_DE_summary.csv"), row.names = FALSE)
} else {
  combined_results <- NULL
}



if (!is.null(combined_results)) {
  
  plot_volcano <- function(results, cell_type, tissue) {
    cell_data <- results[results$cell_type == cell_type, ]
    
    top_up <- cell_data %>%
      filter(direction == "+") %>%
      arrange(desc(avg_log2FC)) %>%
      head(5)
    
    top_down <- cell_data %>%
      filter(direction == "-") %>%
      arrange(avg_log2FC) %>%
      head(5)
    
    
    p <- ggplot(cell_data, aes(x = avg_log2FC, y = -log10(p_val_adj), 
                               color = direction, size = -log10(p_val_adj))) +
      geom_point(alpha = 0.6) +
      geom_vline(xintercept = c(-logfc_threshold, logfc_threshold), 
                 linetype = "dashed", color = "gray50") +
      geom_hline(yintercept = -log10(pval_threshold), 
                 linetype = "dashed", color = "gray50") +
      geom_text_repel(data = top_genes, 
                      aes(label = paste0(gene, "\n", 
                                         "logFC=", round(avg_log2FC, 2), 
                                         "\np.adj=", format.pval(p_val_adj, digits = 2))),
                      size = 3,
                      max.overlaps = 20,
                      box.padding = 0.5,
                      segment.color = "gray") +
      scale_color_manual(values = c("-" = "blue", "ns" = "gray", "+" = "red")) +
      scale_size_continuous(range = c(1, 3)) +
      labs(title = paste(tissue, "-", cell_type, "Differential Expression"),
           subtitle = paste(group_names[2], "vs", group_names[1]),
           x = "Log2 Fold Change",
           y = "-Log10(Adjusted p-value)",
           color = "Direction",
           size = "-Log10(p.adj)") +
      theme_minimal(base_size = 12) +
      theme(legend.position = "bottom",
            plot.title = element_text(face = "bold", size = 14),
            plot.subtitle = element_text(size = 12))
    
    return(p)
  }
  
  
  volcano_plots <- list()
  for (cell_type in names(all_results)) {
    volcano_plots[[cell_type]] <- plot_volcano(combined_results, cell_type, tissue_name)
    
    filename <- paste0(tissue_name, "_", cell_type, "_volcano.pdf")
    ggsave(file.path(output_dir, filename), 
           volcano_plots[[cell_type]], 
           width = 8, height = 7)
  }
  
  
  if (length(volcano_plots) > 0) {
    combined_plot <- plot_grid(plotlist = volcano_plots, ncol = 2)
    
    title <- ggdraw() + 
      draw_label(paste(tissue_name, "Differential Expression Summary:", 
                       group_names[2], "vs", group_names[1]),
                 fontface = 'bold', size = 18, x = 0.5, hjust = 0.5)
    
    subtitle_text <- paste(
      "Tissue:", tissue_name,
      "| Parameters: logFC threshold =", logfc_threshold,
      "| p-value threshold =", pval_threshold,
      "| FDR method =", fdr_method
    )
    subtitle <- ggdraw() + 
      draw_label(subtitle_text, size = 14, x = 0.5, hjust = 0.5)
    
    final_plot <- plot_grid(
      title,
      subtitle,
      combined_plot,
      ncol = 1,
      rel_heights = c(0.1, 0.05, 1)
    )
    
    filename <- paste0(tissue_name, "_DE_summary_plot.pdf")
    ggsave(file.path(output_dir, filename), 
           final_plot, width = 16, height = 8 * ceiling(length(volcano_plots)/2))
  }
  
  
  combined_results <- combined_results %>%
    select(tissue, everything())
  write.csv(combined_results, file.path(output_dir, "all_celltypes_DE_summary.csv"), row.names = FALSE)
}


save.image(file.path(output_dir, paste0(tissue_name, "_scRNA_DE_workspace.RData")))

