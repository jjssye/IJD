

library(GenomicSEM)


load("../ld-score_regression/LDSCoutput.RData")


covstruc<-LDSCoutput


estimation<-"DWLS"


PFactor <- commonfactor(covstruc=covstruc,
                        estimation=estimation)


print(PFactor)


save(PFactor,file = "PFactor.RData")
data.table::fwrite(PFactor$modelfit,
                   file = "STable4a.txt",
                   sep = "\t")
data.table::fwrite(PFactor$results,
                   file = "STable4b.txt",
                   sep = "\t")

