
library(data.table)
library(Fast2TWAS)


fine_mapping_result <- fread("echolocatoR_result.txt")
colnames(fine_mapping_result)[colnames(fine_mapping_result) == "Locus"] <- "NearestGene"


fwrite(fine_mapping_result, 
       file = "STable10.txt", 
       sep="\t")


load("echolocatoR_result.RData")
fine_mapping_result <- results[["merged_dat"]]
colnames(fine_mapping_result)[colnames(fine_mapping_result) == "Locus"] <- "NearestGene"


fwrite(fine_mapping_result, 
       file = "STable10.txt", 
       sep="\t")


