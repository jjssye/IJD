

library(Seurat)
library(SeuratObject)


if (file.exists("mmRNAas.rds")) {
  seurat_as <- readRDS("mmRNAas.rds")
  cat("已读取 mmRNAas.rds: ", ncol(seurat_as), "个细胞\n")
} else {
  stop("找不到 mmRNAas.rds 文件")
}


if (file.exists("mmRNAra.rds")) {
  seurat_ra <- readRDS("mmRNAra.rds")
  cat("已读取 mmRNAra.rds: ", ncol(seurat_ra), "个细胞\n")
} else {
  stop("找不到 mmRNAra.rds 文件")
}


if (file.exists("mmRNApsa.rds")) {
  seurat_psa <- readRDS("mmRNApsa.rds")
  cat("已读取 mmRNApsa.rds: ", ncol(seurat_psa), "个细胞\n")
} else {
  stop("找不到 mmRNApsa.rds 文件")
}


if (!all(c(inherits(seurat_as, "Seurat"), 
           inherits(seurat_ra, "Seurat"), 
           inherits(seurat_psa, "Seurat")))) {
  stop("所有输入文件必须是Seurat对象")
}


sample_names <- c("AS", "RA", "PSA")



case_combined <- merge(
  x = seurat_as,
  y = list(seurat_ra, seurat_psa),
  add.cell.ids = sample_names,
  project = "CaseGroup"
)



case_combined$group <- "Case"


saveRDS(case_combined, file = "case_combined_AMI_hf.rds")



if (file.exists("mmRNAhc.rds")) {
  seurat_hc <- readRDS("mmRNAhc.rds")
  cat("已读取 mmRNAhc.rds: ", ncol(seurat_hc), "个细胞\n")
} else {
  stop("找不到 mmRNAhc.rds 文件")
}



if (file.exists("case_combined.rds")) {
  case_combined <- readRDS("case_combined.rds")
  cat("已读取 case_combined.rds: ", ncol(case_combined), "个细胞\n")
} else {
  stop("找不到 case_combined.rds 文件，请先运行第一步")
}



if (!"sample_id" %in% names(case_combined@meta.data) && "orig.ident" %in% names(case_combined@meta.data)) {
  case_combined$sample_id <- case_combined$orig.ident
}


seurat_hc$group <- "HC"


final_combined_corrected <- merge(
  x = case_combined,
  y = seurat_hc,
  project = "CombinedStudy"
)


print(table(final_combined_corrected$orig.ident))
print(table(final_combined_corrected$group))


if ("sample_id" %in% names(final_combined_corrected@meta.data)) {
  print(table(final_combined_corrected$sample_id))
} else if ("orig.ident" %in% names(final_combined_corrected@meta.data)) {
  print(table(final_combined_corrected$orig.ident))
}


print(final_combined_corrected)


saveRDS(final_combined_corrected, file = "final_combined.rds")





