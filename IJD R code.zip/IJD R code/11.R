

library(Fast2TWAS)
library(ggplot2)
library(qqman)


wind_size = 250000
build = 37
width_LocusZoom = 8
height_LocusZoom = 6
width=14
height=6
sig.thres = 5e-8

result_path="./LocusZoom/"
if (!dir.exists(result_path)) {
  dir.create(result_path)
}


for (snp in GenomicRiskLoci$rsID) {
  i=which(snp == GenomicRiskLoci$rsID)
  message("\n当前第",i,"个GenomicRiskLoci,LeadSNPs：",GenomicRiskLoci[i,]$rsID)
  locusZoom_gassocplot2(gwasfile=metafile,
                        wind_size = wind_size,
                        SNP = snp,
                        bfile = "../1000Gv3/EUR"  ,
                        plink_bin = friendlypostGWASsoft::plink_binary(),
                        title="LocusZoom plots of GWAS top lead SNP",
                        sig.thres = sig.thres,
                        width = width_LocusZoom,
                        height = height_LocusZoom,
                        build = build,
                        outfile = paste0(result_path,"/Sfig_",snp))
}  


geneManhattan=data.table::fread(paste0(FUMA_path,"/magma.genes.out"))
geneManhattan=subset(geneManhattan,CHR!="X")
geneManhattan$CHR=as.numeric(geneManhattan$CHR)


geneManhattan$FDR=p.adjust(p = geneManhattan$P, method = "fdr")


data.table::fwrite(geneManhattan,
                   file =paste0("magma_gene_based.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


mergedata_sig=subset(geneManhattan,FDR<0.05)

data.table::fwrite(mergedata_sig,
                   file =paste0("magma_gene_based_sig.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


pdf(file = paste0("geneManhattan.pdf"), width = width, height = height)
manhattan(geneManhattan,
          chr = "CHR",
          bp = "START",
          p = "P",
          col = sample(rainbow(11)),  
          snp = "SYMBOL",
          main = "",
          ylab = '-log10(P-value)',
          ylim = c(0, 10 * ceiling(max(-log10(na.omit(geneManhattan$P))) / 10)),
          genomewideline = -log10(0.05 / nrow(geneManhattan)), 
          suggestiveline = -log10(0.05),
          annotatePval = 0.05 / nrow(geneManhattan),
          logp = TRUE)
dev.off()


png(filename =paste0("SFig1.png"), width = height*100, height = height*100, units = "px")
qq(snpManhattan$pval)
dev.off()


z = snpManhattan$beta/snpManhattan$se
lambda = round(median(z^2) / 0.454, 3)
print(lambda)

