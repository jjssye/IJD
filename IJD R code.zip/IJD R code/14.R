
library(tidyverse)
library(Fast2TWAS)
library(data.table)


FUMA_path=list.dirs(path = "../FUMA/",full.names = T,recursive = F)


dat_leadSNPs <- fread("../lead_snp_cf/STable6.txt")
dat_leadSNPs_new <- dat_leadSNPs %>% separate_rows(IndSigSNPs, sep = ";")


dat_gwascatalog <- fread(paste0(FUMA_path,"/gwascatalog.txt"))


merge_data <- merge(dat_leadSNPs_new[,c("Novel","rsID","IndSigSNPs","nearestGene")],dat_gwascatalog,by.x = "IndSigSNPs", by.y = "IndSigSNP")
colnames(merge_data)[colnames(merge_data) == "rsID"] <- "Lead SNP"
colnames(merge_data)[colnames(merge_data) == "snp"] <- "One of the independent significant SNPs that are in LD with the SNP."

fwrite(subset(merge_data, select = -c(Novel,IndSigSNPs)),
       file = "STable8.txt",
       sep = "\t")

merge_data_df <- merge(dat_leadSNPs_df,dat_gwascatalog,by.x = "IndSigSNPs", by.y = "IndSigSNP")
colnames(merge_data_df)[colnames(merge_data_df) == "rsID"] <- "Lead SNP"
colnames(merge_data_df)[colnames(merge_data_df) == "snp"] <- "rsID of reported SNP in GWAS catalog"


fwrite(subset(merge_data_df, select = -c(Novel,IndSigSNPs)),
       file = "STable9.txt",
       sep = "\t")

pre_table1 <- merge_data_df[,c("Lead SNP","CHR","BP","non_effect_allele","effect_allele","MAF","p","beta","se")]

pre_table1_df <- merge(pre_table1,dat_leadSNPs_new[,c("rsID","nearestGene","Q_pval")],by.x = "Lead SNP", by.y = "rsID",all.x = T)
colnames(pre_table1_df)[colnames(pre_table1_df) == "Lead SNP"] <- "SNP"

pre_table1_df <- pre_table1_df %>% distinct()

pre_table1_df$`Previous GWAS associations` <- NA
for (i in pre_table1_df$SNP){
  pre_table1_df[pre_table1_df$SNP==i,]$`Previous GWAS associations` <- paste0(merge_data_df[merge_data_df$`Lead SNP`==i,]$Trait,collapse = ", ")
}


fwrite(pre_table1_df,
       file = "Table1.txt",
       sep = "\t")

