
library(Fast2TWAS)
library(MendelianRandomization)

trait="IJD"


IVW_Wald_ratio_sig=data.table::fread(paste0("../fdr_mendelian_randomization_decode/",trait,"_IVW_Wald_ratio_sig_MR_result.txt"))


ConMix="./Contamination_mixture/"
if (!dir.exists(ConMix)) {
  dir.create(ConMix)
}


for (protein in IVW_Wald_ratio_sig$exposure) {
  i=which(protein == IVW_Wald_ratio_sig$exposure)
  message("\n当前第",i,"个暴露:",protein)
  dat=data.table::fread(paste0(path,protein,"_",trait,".Mendelian_IVs.txt")) %>% data.frame()
  
  
  object <- mr_input(
    bx = dat$beta.exposure,
    bxse = dat$se.exposure,
    by = dat$beta.outcome,
    byse = dat$se.outcome,
    correlation = matrix(),
    exposure = protein,
    outcome = trait,
    snps = "SNP",
    effect_allele = dat$effect_allele.exposure,
    other_allele = dat$other_allele.exposure,
    eaf = dat$eaf.exposure)

  Contamination_mixture <- try(mr_conmix(object, psi = 0, CIMin = NA, CIMax = NA, CIStep = 0.01, alpha = 0.05), silent =T)
  
  print(Contamination_mixture)
  
  if ("try-error" %in% class(Contamination_mixture)) {
    line=paste0(protein," 筛选后的工具变量不满足mr_conmix分析条件，直接跳过该蛋白")
    write(x = line, file = "contamination_mixture_decode.log", append = T)
    message(line)
    next}
  
  save(Contamination_mixture, 
       file = paste0(ConMix,protein,".RData"))
  
  Contamination_mixture_single=data.frame(
    exposure=protein,
    gene=IVW_Wald_ratio_sig$gene[i],
    method="ConMix",
    Instruments=paste0(unlist(strsplit(dat[dat$mr_keep==TRUE,]$SNP, "; ")),collapse = ";"),
    nSNPs=length(dat[dat$mr_keep==TRUE,]$SNP),
    beta=Contamination_mixture@Estimate,
    CILower=Contamination_mixture@CILower[1],
    CIUpper=Contamination_mixture@CIUpper[1],
    pval=Contamination_mixture@Pvalue)
  
  all_Contamination_mixture=rbind(Contamination_mixture_single,all_Contamination_mixture)
  
}  


data.table::fwrite(all_Contamination_mixture,
                   file =paste0(trait,"_Contamination_mixture_MR_result.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


