
library(TwoSampleMR)

trait="IJD"

ukb_ppp_sample_size=34557

path="../mendelian_randomization_UKB_PPP/result/"

IVW_Wald_ratio_sig=data.table::fread(paste0("../fdr_mendelian_randomization_UKB_PPP/",trait,"_IVW_Wald_ratio_sig_MR_result.txt"))


Fstat_dat <- data.frame()
for (protein in ukb_ppp_sig) {
  i=which(protein == ukb_ppp_sig)
  message("\n当前第",i,"个暴露:",protein)
  dat=data.table::fread(paste0(path,protein,"_",trait,".Mendelian_IVs.txt")) %>% data.frame()
  
 
  dat <- add_rsq(dat)
  
  total_R2 <- sum(dat$rsq.exposure)

  
  N = ukb_ppp_sample_size
  
  K = length(dat$SNP)
  

  Fstat_dat_single <- data.frame(
    exposure=protein,
    gene=IVW_Wald_ratio_sig$gene[i],
    Instruments=subset(IVW_Wald_ratio_sig,exposure==protein)$Instruments,
    nSNPs=subset(IVW_Wald_ratio_sig,exposure==protein)$nSNPs,
    Fstat=total_Fstat)
  Fstat_dat <- rbind(Fstat_dat_single,Fstat_dat)
  
}  



data.table::fwrite(Fstat_dat,
                   file =paste0(trait,"_ukb_ppp_Fstat.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


