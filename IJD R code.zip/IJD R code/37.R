
library(Fast2TWAS)

trait="IJD"


IVW_method="Fixed"

clump_kb=10000
r2=0.1
P_th <- 5e-8


decode_dat=data.table::fread("../deCODE/decode2021_protein_annotation(clean).txt")
decode_Phenotype=unique(decode_dat$labels)


dat <- data.table::fread(metafile)


dat_sig <- subset(dat,pval<P_th)


data.table::fwrite(dat_sig,
                   file = paste0(trait,"_",IVW_method,"_hg38_sig.txt"),
                   sep = "\t")


write(x = "", file = "Reverse_mendelian_randomization_decode.log", append = F)
setwd(result_path)

for (protein in decode_Phenotype) {
  i=which(protein==decode_Phenotype)
  message("\n当前第",i,"个结局：",protein)

  
  mr_result <- try(mendelian_randomization(exposure_dat=paste0("../",trait,"_",IVW_method,"_hg38_sig.txt"),
                                           outcome_dat = paste0("../../deCODE/decode_pqtl_cis_1mb_hg38/hg38_decode_pqtl_cis_1mb_",protein,".txt"),
                                           pval = P_th,
                                           exposure_trait = trait,
                                           outcome_trait = protein,
                                           clump_local = T,
                                           clump_kb = clump_kb,
                                           r2 = r2,
                                           bfile = paste0("../../1000Gv3/EUR"),
                                           method_list = subset(TwoSampleMR::mr_method_list(), use_by_default)$obj,
                                           F_method = 2, 
                                           Ffilter = 10,
                                           NbDistribution = NULL,
                                           mr_report = FALSE,
                                           plot = FALSE), silent =T)
  
  
  if ("try-error" %in% class(mr_result)) {
    line=paste0(paste0(trait,"_",IVW_method,"_hg38_sig.txt")," 筛选后的工具变量在",protein,"中找不到直接跳过")
    message(line)
    write(x = line, file = "../Reverse_mendelian_randomization_decode.log", append = T)
    next}
}


