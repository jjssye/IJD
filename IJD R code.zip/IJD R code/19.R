
library(Fast2TWAS)
library(data.table)


tissues=c("sCCA1","sCCA2","sCCA3")


focusdata=TWAS_focus_format_clean(gwasfile="../fuma_PSYCH_factor.txt",
                                  flag_options="--chunksize 500000",
                                  outname = "fuma_PSYCH_factor",
                                  force = F) 


for (tissue in tissues) {
focusall=TWAS_focus_fine_mapping_multiprocess(gwasfile="./fuma_PSYCH_factor.focus.sumstats.gz",
                                              eQTL_db_weight = paste0("../FOCUS/",tissue,".db"),
                                              LDREF = "../FOCUS/1000G_EUR_Phase3_plink/1000G.EUR.QC",
                                              outname = paste0("fuma_PSYCH_factor","_",tissue,"_focus"),
                                              startChr = 1,
                                              endChr = 22,
                                              plot = TRUE,
                                              flag_options=NULL,
                                              locations  = "../FOCUS/grch37.eur.loci - 副本.bed",
                                              pval_threshold = 5e-8,
                                              nthread = 4,
                                              force = F)
}



fwrite(focusallresult,
       file ="focus_allresult.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)


