
library(data.table)


gwas_data <- fread(gwas_file_path)


p_value_colname <- "pval" 
snp_colname <- "SNP"   


threshold <- 1e-5  
top_gwas_snps <- gwas_data[get(p_value_colname) < threshold, ]



ijd_prs <- fread(prs_file_path)

colnames(ijd_prs) <- c("SNP", "A1_ijd", "beta_ijd")


ijd_top_prs <- ijd_prs[SNP %in% top_gwas_snps[[snp_colname]]]


output_filename <- "score_IJD_top_snps.txt"


fwrite(ijd_top_prs, output_filename, sep = "\t")


library(ggplot2)


df <- data.frame(
  Disease = factor(c("RA", "PsA", "AS"), levels = c("RA", "PsA", "AS")),
  Percent = c(51.99, 52.96, 50.97),
  P_value = c(0.1125085, 0.0342915, 0.2827596),
  N_SNPs = c(981, 980, 981),
  Consistent = c(510, 519, 500)
)





df$Significance <- ifelse(df$P_value < 0.05, 
                          "Significant (P < 0.05)", 
                          "Not Significant")


p <- ggplot(df, aes(x = Disease, y = Percent, fill = Significance)) +
  
  geom_col(width = 0.55, color = "black", linewidth = 0.5, alpha = 0.9) +
  
  
  geom_hline(yintercept = 50, linetype = "dashed", color = "gray30", linewidth = 1) +
  
  
  geom_text(aes(label = sprintf("%.2f%%\nP = %.3f", Percent, P_value)), 
            vjust = -0.5, size = 4.5, fontface = "bold", color = "gray20") +
  
  
  annotate("text", x = 0.6, y = 50.5, label = "50% Random Chance", 
           color = "gray30", size = 3.5, fontface = "italic", hjust = 0) +
  
 
  scale_fill_manual(values = c("Significant (P < 0.05)" = "#E64B35", 
                               "Not Significant" = "#4DBBD5")) +
  
  
  scale_y_continuous(limits = c(0, 56), breaks = seq(0, 55, by = 10)) +
  
  
  labs(title = "Directional Consistency of European IJD PRS in East Asian Cohorts",
       subtitle = "Analysis based on 980+ top significant SNPs (P < 1e-5)",
       x = "Taiwanese GWAS Traits",
       y = "Directional Consistency (%)") +
  
  
  theme_classic(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5, size = 15, margin = margin(b = 10)),
    plot.subtitle = element_text(hjust = 0.5, size = 12, color = "gray40", margin = margin(b = 15)),
    legend.position = "top",
    legend.title = element_blank(),
    axis.text.x = element_text(face = "bold", size = 12, color = "black"),
    axis.text.y = element_text(size = 11, color = "black"),
    axis.title.y = element_text(face = "bold", margin = margin(r = 10)),
    axis.title.x = element_text(face = "bold", margin = margin(t = 10))
  )


print(p)


ggsave("IJD_Taiwan_Consistency_Publication.png", plot = p, 
       width = 7.5, height = 6, dpi = 300)



library(ggplot2)


psa_data <- read.csv("IJD_TopSNPs_vs_PsA_details.csv", stringsAsFactors = FALSE)



psa_consistent <- subset(psa_data, consistent == TRUE)


enrichment_input <- psa_consistent[, c("SNP", "A1_ijd", "beta_ijd", "beta_tw_adj")]

output_file <- "PsA_Consistent_519_SNPs_for_Enrichment.txt"


write.table(enrichment_input, output_file, 
            row.names = FALSE, col.names = TRUE, quote = FALSE, sep = "\t")



cor_res <- cor.test(psa_consistent$beta_ijd, psa_consistent$beta_tw_adj)



p <- ggplot(psa_consistent, aes(x = beta_ijd, y = beta_tw_adj)) +
  
  geom_point(alpha = 0.6, color = "#0073C2", size = 2.5) +
  
  geom_smooth(method = "lm", color = "#E64B35", fill = "lightgray", alpha = 0.4) +
  
  
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray50", linewidth = 0.8) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "gray50", linewidth = 0.8) +
  
  
  labs(title = "Effect Size Correlation of Shared Genetic Variants",
       subtitle = "European IJD vs. Taiwanese PsA (519 Directionally Consistent SNPs)",
       x = "European IJD Effect Size (Beta)",
       y = "Taiwanese PsA Effect Size (Beta)") +
  
  
  annotate("text", 
           x = min(psa_consistent$beta_ijd) * 0.8, 
           y = max(psa_consistent$beta_tw_adj) * 0.9, 
           label = cor_text, size = 5, fontface = "italic", color = "black", hjust = 0) +
  
  
  theme_classic(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5, size = 16),
    plot.subtitle = element_text(hjust = 0.5, color = "gray40", size = 12, margin = margin(b = 15)),
    axis.title.x = element_text(face = "bold", margin = margin(t = 10)),
    axis.title.y = element_text(face = "bold", margin = margin(r = 10)),
    axis.text = element_text(color = "black")
  )

print(p)


ggsave("PsA_519_SNPs_Beta_Correlation.png", plot = p, width = 8, height = 6, dpi = 300)





