


library(Fast2TWAS)

filename=c("AS.txt",
           "PSA.txt",
           "RA.txt",
           "othInspa.txt",
           "othpsoA.txt")

phenotype=c("AS",
            "PSA",
            "RA",
            "othInspa",
            "othpsoA")

cases = c(3838,
          5065,
          8255,
          656,
          1433)

controls = c(353224,
             21286,
             409001,
             164682,
             217013)

samplesize=c(357062,
             26351,
             409001,
             165338,
             218446)

ismeta = c(FALSE, 
           FALSE, 
           TRUE, 
           FALSE, 
           FALSE)

population.prev <- c(0.003, 
                     0.003, 
                     0.012, 
                     0.01, 
                     0.0015)

input_info_data <- data.frame(filename=filename,
                              phenotype=phenotype,
                              cases=cases,
                              controls=controls,
                              samplesize=samplesize,
                              ismeta=ismeta,
                              population.prev=population.prev)


data.table::fwrite(input_info_data,
                   file = "gwasfile_info.txt",
                   na = "NA",
                   quote = FALSE,
                   sep = "\t")
