


library(GenomicSEM)

load("../LDSCoutput.RData")
load("../PSYCH_sumstats.RData")


covstruc=LDSCoutput


SNPs=PSYCH_sumstats

estimation="DWLS"

cores= ifelse( Sys.info()["sysname"]!="Linux",parallel::detectCores(),parallel::detectCores()/2)

cores=floor(parallel::detectCores()=0.75)
total_cores <-parallel::detectCores()

toler=1e-60

SNPSE=FALSE

parallel=TRUE

GC = "standard"

MPI=FALSE

TWAS=FALSE

smooth_check=FALSE



random_numbers <- sample(1:nrow(SNPs), 10000)
compiler::loadcmp("../try_commonfactorGWAS.Rc", env = environment())

compiler::loadcmp("../commonfactorGWAS.Rc", env = environment())

load("PSYCH_factor.RData")

PSYCH_factor_limit_MAF<-subset(PSYCH_factor, PSYCH_factor$MAF <= 0.4 & PSYCH_factor$MAF >= 0.1)

N_hat<-mean(1/((2*PSYCH_factor_limit_MAF$MAF*(1-PSYCH_factor_limit_MAF$MAF))*PSYCH_factor_limit_MAF$se_c^2))


print(N_hat)


PSYCH_factor$N_hat <- N_hat

print(PSYCH_factor)


save(PSYCH_factor,N_hat,file="PSYCH_factor_with_N_hat.RData")
data.table::fwrite(PSYCH_factor,
                   file = "PSYCH_factor_with_N_hat.txt",
                   sep = "\t")

