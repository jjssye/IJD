
library(Fast2TWAS)


inputFile=c("IJD") 


#in Python
#conda install -c bioconda -c conda-forge snakemake">=5.27.4"
#conda env create -f "./ldsc/environment_munge_ldsc.yml"



python_path <-  reticulate::conda_python(envname = "munge_ldsc", conda = "auto", all = FALSE)
shell <- ifelse(Sys.info()["sysname"] == "Windows", "cmd","sh")

for (trait in inputFile) {
  munge <- paste0(shQuote(python_path, type = shell),
                 " ./CELLECT/ldsc/mtag_munge.py",
                 " --sumstats  ../07.hg19Tohg38/",trait,"_hg38_qc.txt",
                 " --merge-alleles ./CELLECT/data/ldsc/w_hm3.snplist",
                 " --keep-pval",
                 " --out ",trait)
  
  
  system(munge)
}  


for (trait in inputFile) {
  munge <- paste0(shQuote(python_path, type = shell),
                  " ./CELLECT/ldsc/mtag_munge.py",
                  " --sumstats  ../07.hg19Tohg38/",trait,".txt",
                  " --merge-alleles ./CELLECT/data/ldsc/w_hm3.snplist",
                  " --keep-pval",
                  " --out ",trait)
  
  
  system(munge)
}  


#in Python
#pip install pybedtools   -i http://mirrors.aliyun.com/pypi/simple --trusted-host  mirrors.aliyun.com
#pip install statsmodels   -i http://mirrors.aliyun.com/pypi/simple --trusted-host  mirrors.aliyun.com

#in Python
#snakemake --use-conda -j 4 -s cellect-ldsc.snakefile --configfile config.yml
#snakemake --use-conda -j 4  -s cellect-magma.snakefile --configfile config.yml



