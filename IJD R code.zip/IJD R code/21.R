
library(data.table)


FUMA_path=list.dirs(path = "../fuma/",full.names = T,recursive = F)


MAGMA=fread(paste0(FUMA_path,"/magma.genes.out"))


MAGMA=MAGMA[,c("GENE","SYMBOL","CHR","START","STOP","ZSTAT","P")]


MAGMA$P_bon=p.adjust(MAGMA$P,method = "bonferroni")
MAGMA_significant=MAGMA[MAGMA$P_bon<0.05,] 


fwrite(MAGMA,
       file ="pre_STable12.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)

fwrite(MAGMA_significant,
       file ="STable12.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)


