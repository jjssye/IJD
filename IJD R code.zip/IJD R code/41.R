
library(Fast2TWAS)


inputFile=c("IJD")


for (trait in inputFile) {
  for (qtl_type in c("best_eqtl")) {
  QTLEnrich_run(gwas_file=paste0("../hg19Tohg38/",trait,"_hg38_qc_QTLEnrich.txt"),
                qtl_directory="../GTEx_Analysis_v8_eQTL/",
                file_name=".v8.egenes.txt.gz",
                qtl_type=qtl_type,
                confounders_table="../GTEx_v8_Confounders_Table_49Tiss_Global.txt.gz",
                null_table="../GTEx_v8_Null_Table_49Tiss_Global.txt.gz",
                is_subset_genes=TRUE,
                is_compute_tss_distance=TRUE,
                is_keep_gene_id_suffix=TRUE,
                is_keep_null_variants=TRUE,
                is_keep_pvalue_matrix=TRUE,
                gencode_file="../QTLEnrich/GENCODE_26_df.txt",
                null_option=NULL,
                genome_build=NULL,
                trait_name=trait,
                gwas_p_value=NULL,
                independent_ranking=NULL,
                lambda_factor=NULL,
                lower_bound_permutations=NULL,
                upper_bound_permutations=NULL,
                num_quantiles=NULL,
                tissue_names=NULL,
                is_subset_tissues=FALSE,
                exp_label=trait,
                is_GeneEnrich_input=TRUE,
                eGenes_directory=NULL,
                eGenes_file_name=NULL,
                flag_options=NULL)
  }
}


