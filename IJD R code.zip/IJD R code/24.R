
library(Fast2TWAS)
library(data.table)


n_gwas=1453231042


data <-fread("../fuma_PSYCH_factor.gz")
sst <- data[,.(SNP,effect_allele,other_allele,beta,se)]
colnames(sst) <- c("SNP","A1","A2","BETA","SE")
bim <- data[,.(CHR,SNP,0,BP,effect_allele,other_allele)]


fwrite(sst, "sumstats.txt", sep = "\t", quote = FALSE)
fwrite(bim, "bim_prefix.bim", sep = "\t", quote = FALSE,col.names = F)


PRS_CS_run(
  outname = "PRS_CS_result",
  ref_dir = "../ldblk_1kg_eur/",
  bim_prefix = "bim_prefix.bim",
  sst_file = "sumstats.txt",
  n_gwas = n_gwas,
  a = 1,
  b = 0.5,
  phi = 0.01,
  n_iter = 1000,
  n_burnin = 500,
  thin = 5,
  chrom = NULL,
  beta_std = FALSE,
  write_psi = FALSE,
  write_pst = FALSE,
  seed = 123,
  force = FALSE
)



unlink(c("sumstats.txt","bim_prefix.bim"), recursive = TRUE, force = TRUE)

