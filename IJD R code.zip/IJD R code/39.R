
library(Fast2TWAS)

trait="IJD"


IVW_method="Fixed"

clump_kb=10000
r2=0.1
P_th <- 5e-8

ukb_ppp_dat=data.table::fread("../ukb_ppp/olink_protein_map_3k_v1.tsv")


result_path="./result/"
if (!dir.exists(result_path)) {
  dir.create(result_path)
}


write(x = "", file = "Reverse_mendelian_randomization_UKB_PPP.log", append = F)


for (protein in ukb_ppp_dat$labels) {
  i=which(protein==ukb_ppp_dat$labels)
  message("\n当前第",i,"个结局：",protein)

  
  exposure_file=paste0("../../ukb_ppp/ukb_ppp_pqtl_cis_1mb_hg38/hg38_ukb_ppp_pqtl_cis_1mb_",protein,".txt")
  if (!file.exists(exposure_file)) {
    line=paste0(metafile," 未能成功与",protein,"进行孟德尔随机化，直接跳过")
    message(line)
    write(x = line, file = "../Reverse_mendelian_randomization_UKB_PPP.log", append = T)
    next
  }
  mr_result <- try(mendelian_randomization(exposure_dat=paste0("../",metafile),
                                           outcome_dat = exposure_file,
                                           pval = P_th,
                                           exposure_trait = trait,
                                           outcome_trait = protein,
                                           clump_local = T,
                                           clump_kb = clump_kb,
                                           r2 = r2,
                                           bfile = "../../1000Gv3/EUR",
                                           method_list = subset(TwoSampleMR::mr_method_list(), use_by_default)$obj,
                                           F_method = 2, #利用beta^2/se^2计算
                                           Ffilter = 10,
                                           mr_report = FALSE,
                                           plot = FALSE), silent =T)
  
  
  if ("try-error" %in% class(mr_result)) {
    line=paste0(metafile," 未能成功与",protein,"进行孟德尔随机化，直接跳过")
    message(line)
    write(x = line, file = "../Reverse_mendelian_randomization_UKB_PPP.log", append = T)
    next}
}


