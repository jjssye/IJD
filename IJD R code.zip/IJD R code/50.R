


library(dplyr)
library(Seurat)
library(scTenifoldKnk)
library(ggplot2)
library(ggrepel)


mmRNA_harmony <- readRDS("harmony_corrected_seurat_IJD.rds")



countMatrix <- GetAssayData(mmRNA_harmony, slot = "counts")
set.seed(123)


total_cells <- ncol(countMatrix)


if(total_cells > 10000){
  sampled_indices <- sample(1:total_cells, 10000)
  small_countMatrix <- countMatrix[, sampled_indices]
} else {
  small_countMatrix <- countMatrix
}


result <- scTenifoldKnk(
  countMatrix = small_countMatrix, 
  gKO = c('OSMR', 'LIFR'),         
  qc_mtThreshold = 0.1,  
  qc_minLSize = 1000,    
  nc_nNet = 10,          
  nc_nCells = 500,       
  nc_nComp = 3           
)


saveRDS(result, "scTenifoldKnk_OSMR_LIFR_KO_results.rds")


top_genes <- head(result$diffRegulation[order(-result$diffRegulation$FC), ], 20)


p1 <- ggplot(top_genes, aes(x = reorder(gene, FC), y = FC)) +
  geom_bar(stat = 'identity', fill = 'steelblue') +
  coord_flip() +
  labs(title = "Top 20 Differentially Regulated Genes after OSMR & LIFR KO", # 【修正】：更新标题
       x = "Gene", y = "Fold Change") +
  theme_minimal()


pdf(file.path(output_dir, "top20_genes_OSMR_LIFR_barplot.pdf"), width = 10, height = 8)
print(p1)
dev.off()

png(file.path(output_dir, "top20_genes_OSMR_LIFR_barplot.png"), width = 1000, height = 800, res = 150)
print(p1)
dev.off()


df <- result$diffRegulation
df$log_pval <- -log10(df$p.adj)
label_genes <- subset(df, abs(Z) > 2 & p.adj < 0.01)

p2 <- ggplot(df, aes(x = Z, y = log_pval)) +
  geom_point(alpha = 0.5) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "red") +
  geom_vline(xintercept = c(-2, 2), linetype = "dashed", color = "blue") +
  geom_text_repel(data = label_genes, aes(label = gene),
                  size = 3, max.overlaps = 50) +
  labs(title = "Virtual Knockout of OSMR & LIFR: Z-score vs -log10(p.adj)", # 【修正】：更新标题
       x = "Z-score", y = "-log10(adjusted p-value)") +
  theme_classic()


pdf(file.path(output_dir, "volcano_plot_OSMR_LIFR.pdf"), width = 12, height = 8)
print(p2)
dev.off()

png(file.path(output_dir, "volcano_plot_OSMR_LIFR.png"), width = 1200, height = 800, res = 150)
print(p2)
dev.off()


