

library(TwoSampleMR)


FileNames <- list.files(getwd(), pattern = ".csv")
exp_dat_ids <- FileNames
exps <- FileNames


outcome_file <- "IJD.txt"
out <- fread(outcome_file, header = TRUE)
out$trait <- '38'
outcomeid <- out
head(outcomeid)


output_dir <- "mendelian_test"
dir.create(path = output_dir)


get_f_noeaf <- function(dat, F_value = 10) {
  if(is.null(dat$beta.exposure[1]) || is.na(dat$beta.exposure[1])) {
    print("数据不包含beta，无法计算F统计量")
    return(dat)
  }
  if(is.null(dat$se.exposure[1]) || is.na(dat$se.exposure[1])) {
    print("数据不包含se，无法计算F统计量")
    return(dat)
  }
  if(is.null(dat$samplesize.exposure[1]) || is.na(dat$samplesize.exposure[1])) {
    print("数据不包含samplesize(样本量)，无法计算F统计量")
    return(dat)
  }
  
  R2 <- (dat$beta.exposure^2) / ((dat$se.exposure^2 * dat$samplesize.exposure) + dat$beta.exposure^2)
  F <- (dat$samplesize.exposure - 2) * R2 / (1 - R2)
  dat$R2 <- R2
  dat$F <- F
  dat <- subset(dat, F > F_value)
  return(dat)
}

get_f <- function(dat, F_value = 10) {
  log <- is.na(dat$eaf.exposure)
  log <- unique(log)
  if(length(log) == 1 && log == TRUE) {
    print("数据不包含eaf，无法计算F统计量")
    return(dat)
  }
  if(is.null(dat$beta.exposure[1]) || is.na(dat$beta.exposure[1])) {
    print("数据不包含beta，无法计算F统计量")
    return(dat)
  }
  if(is.null(dat$se.exposure[1]) || is.na(dat$se.exposure[1])) {
    print("数据不包含se，无法计算F统计量")
    return(dat)
  }
  if(is.null(dat$samplesize.exposure[1]) || is.na(dat$samplesize.exposure[1])) {
    print("数据不包含samplesize(样本量)，无法计算F统计量")
    return(dat)
  }
  
  if("FALSE" %in% log) {
    R2 <- (2 * (1 - dat$eaf.exposure) * dat$eaf.exposure * (dat$beta.exposure^2)) / 
      ((2 * (1 - dat$eaf.exposure) * dat$eaf.exposure * (dat$beta.exposure^2)) + 
         (2 * (1 - dat$eaf.exposure) * dat$eaf.exposure * (dat$se.exposure^2) * dat$samplesize.exposure))
    F <- (dat$samplesize.exposure - 2) * R2 / (1 - R2)
    dat$R2 <- R2
    dat$F <- F
    dat <- subset(dat, F > F_value)
    return(dat)
  }
}

steiger_test <- function(dat) {
  dat$r.exposure <- get_r_from_bsen(b = dat$beta.exposure, dat$se.exposure, dat$samplesize.exposure)
  dat$r.outcome <- get_r_from_bsen(b = dat$beta.outcome, dat$se.outcome, dat$samplesize.outcome)
  res_steiger <- mr_steiger(
    p_exp = dat$pval.exposure,
    p_out = dat$pval.outcome,
    n_exp = dat$samplesize.exposure,
    n_out = dat$samplesize.outcome,
    r_exp = dat$r.exposure,
    r_out = dat$r.outcome
  )
  res_steiger <- directionality_test(dat)
  
  return(res_steiger)
}

results_binary <- function(N, alpha, R2xz, K, OR, epower) {
  threschi <- qchisq(1 - alpha, 1) 
  f.value <- 1 + N * R2xz / (1 - R2xz)
  
  if (is.na(epower)) {
    b_MR <- K * (OR / (1 + K * (OR - 1)) - 1)
    v_MR <- (K * (1 - K) - b_MR^2) / (N * R2xz)
    NCP <- b_MR^2 / v_MR
    
    power <- 1 - pchisq(threschi, 1, NCP)
    data.frame(Parameter = c("Power", "NCP", "F-statistic"), Value = c(power, NCP, f.value), Description = c("", "Non-Centrality-Parameter", "The strength of the instrument"))    
  } else {
    z1 <- qnorm(1 - alpha / 2)
    z2 <- qnorm(epower)
    Z <- (z1 + z2)^2
    
    b_01 <- K * (OR / (1 + K * (OR - 1)) - 1)
    f <- K * (1 - K) - b_01^2
    N1 <- Z * f / (b_01^2 * R2xz)
    N1 <- ceiling(N1)
    data.frame(Parameter = "Sample Size", Value = N1)
  }
}

choose_MR <- function(dat = dat) {
  res_hete <- NULL  
  if (nrow(dat) < 3) {
    res <- mr(dat, method_list = c("mr_ivw", "mr_wald_ratio"))
  } else {
    res_hete <- mr_heterogeneity(dat)
    if (res_hete$Q_pval[2] < 0.05) {
      res <- mr(dat, method_list = c(
        "mr_egger_regression", "mr_weighted_median", "mr_ivw_mre", "mr_weighted_mode", "mr_simple_mode"
      ))
    } else {
      res <- mr(dat, method_list = c(
        "mr_egger_regression", "mr_weighted_median", "mr_ivw_fe", "mr_weighted_mode", "mr_simple_mode"
      ))
    }
  }
  AAA <- list(res_hete, res)
  return(list(AAA))
}


process_exposure_data <- function(exp_dat_id, exp, outcomeid) {
  d3 <- try(fread(paste0(getwd(), "/", exp_dat_id), fill = TRUE), silent = TRUE)
  d3 <- subset(d3, d3$pval < 1e-5)
  
  if (nrow(d3) == 0) return(NULL)
  
  d3 <- format_data(as.data.frame(d3), type = "exposure")
  
  d4 <- ld_clump(
    clump_kb = 10000,
    clump_r2 = 0.01,
    pop = "EUR",
    dplyr::tibble(rsid = d3$SNP, pval = d3$pval.exposure, id = d3$id.exposure),
    plink_bin = "plink_win64_20230116/plink.exe",
    bfile = "EUR/EUR"
  )
  
  exp_data <- subset(d3, SNP %in% d4$rsid)
  if (nrow(exp_data) == 0) return(NULL)
  
  outcome_dat <- merge(exp_data, outcomeid, by.x = "SNP", by.y = "SNP")
  if (nrow(outcome_dat) == 0) return(NULL)
  
  write.csv(outcome_dat, file = "d.csv")
  out_data <- read_outcome_data(
    snps = exp_data$SNP,
    filename = "d.csv",
    sep = ","
  )
  
  out_data <- subset(out_data, pval.outcome > 5e-8)
  
  dat <- TwoSampleMR::harmonise_data(
    exposure_dat = exp_data,
    outcome_dat = out_data
  )
  
  dat <- subset(dat, mr_keep == TRUE)
  dat <- get_f(dat, F_value = 10)
  
  res <- choose_MR(dat = dat)
  res1 <- generate_odds_ratios(res[[1]][[2]])
  
  res1$estimate <- paste0(
    format(round(res1$or, 2), nsmall = 2), " (", 
    format(round(res1$or_lci95, 2), nsmall = 2), "-",
    format(round(res1$or_uci95, 2), nsmall = 2), ")"
  )
  
  openxlsx::write.xlsx(dat, file = paste0(output_dir, "/", exp, "-dat.xlsx"), rowNames = FALSE)
  openxlsx::write.xlsx(res1, paste0(output_dir, "/", exp, "-res.xlsx"))
  
  res_steiger <- steiger_test(dat)
  
  N <- dat$samplesize.outcome[1]
  alpha <- 0.05
  R2xz <- sum(dat$R2)
  K <- (dat$ncase.outcome[1] / dat$ncontrol.outcome[1])
  OR <- if (nrow(dat) == 1) {
    res1 %>% filter(method == "Wald ratio") %>% pull(or)
  } else {
    res1 %>% filter(grepl("Inverse variance weighted", method)) %>% pull(or)
  }
  
  epower <- NA
  power <- results_binary(N, alpha, R2xz, K, OR, epower)
  
  res3 <- res1[, -c(10:14)]
  res4 <- tidyr::pivot_wider(
    res3, names_from = "method", names_vary = "slowest",
    values_from = c("b", "se", "pval", "estimate")
  )
  
  colnames(res4) <- gsub("\\(.*\\)", "", colnames(res4))
  
  res_steiger2 <- dplyr::select(res_steiger, correct_causal_direction, steiger_pval)
  power2 <- tidyr::pivot_wider(
    power, names_from = "Parameter", names_vary = "slowest",
    values_from = c("Value", "Description")
  )[, 1]
  
  res_ALL <- cbind(res4, res_steiger2, power2)
  res_ALL$F <- mean(dat$F, na.rm = TRUE)
  res_ALL$R2 <- sum(dat$R2)
  
  if (nrow(dat) <= 2) {
    write.csv(res_ALL, file = paste0(output_dir, "/", exp, "1.csv"), row.names = FALSE)
  } else {
    res_plei <- TwoSampleMR::mr_pleiotropy_test(dat)
    res_leaveone <- mr_leaveoneout(dat)
    
    p1 <- mr_scatter_plot(res[[1]][[2]], dat)
    pdf(paste0(output_dir, "/", exp, "_scatter.pdf"))
    print(p1[[1]])
    dev.off()
    
    res_single <- mr_singlesnp(dat, all_method)
    p2 <- mr_forest_plot(res_single)
    pdf(paste0(output_dir, "/", exp, "_forest.pdf"))
    print(p2[[1]])
    dev.off()
    
    p3 <- mr_funnel_plot(res_single)
    pdf(paste0(output_dir, "/", exp, "_funnel.pdf"))
    print(p3[[1]])
    dev.off()
    
    res_loo <- mr_leaveoneout(dat)
    pdf(paste0(output_dir, "/", exp, "_leave_one_out.pdf"))
    print(mr_leaveoneout_plot(res_loo))
    dev.off()
    
    res_hete <- purrr::map(.x = seq_along(res), .f = ~res[[.x]][[1]])
    res_hete <- do.call(rbind, res_hete)
    res_hete2 <- tidyr::pivot_wider(
      res_hete, names_from = "method", names_vary = "slowest",
      values_from = c("Q", "Q_df", "Q_pval")
    )[, 4:6]
    
    res_plei2 <- dplyr::select(res_plei, egger_intercept, se, pval)
    
    res_ALL <- cbind(res_ALL, res_hete2, res_plei2)
    write.csv(res_ALL, file = paste0(output_dir, "/", exp, ".csv"), row.names = FALSE)
  }
}


for (qaq in 1:length(exp_dat_ids)) {
  process_exposure_data(exp_dat_ids[qaq], exps[qaq], outcomeid)
}


csv_files <- list.files(output_dir, pattern = "\\.csv1\\.csv$|\\.csv\\.csv$", full.names = TRUE)


combined_df <- read.csv(csv_files[1], stringsAsFactors = FALSE)


if (!is.null(combined_df$global_test_p)) {
  combined_df$global_test_p <- as.character(combined_df$global_test_p)
}


for (i in 2:length(csv_files)) {
  temp_df <- read.csv(csv_files[i], stringsAsFactors = FALSE)
  
  if (!is.null(temp_df$global_test_p)) {
    temp_df$global_test_p <- as.character(temp_df$global_test_p)
    temp_df$global_test_p[temp_df$global_test_p == "<"] <- ""
  }
  
  combined_df <- bind_rows(combined_df, temp_df)
}


write.csv(combined_df, "IJD.csv", row.names = FALSE)



