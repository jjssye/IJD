
library(Fast2TWAS)

GWASN=77750


tissues=c("sCCA1","sCCA2","sCCA3")



ldsc=format_LDSC_data(file = "../fuma_PSYCH_factor.txt",
                      SNP="SNP",
                      BETA="beta",
                      SE="se",
                      effect_allele="effect_allele",
                      other_allele = "other_allele",
                      pval = "pval",
                      samplesize = "N",
                      savefile="fuma_PSYCH_factor",
                      sep = "\t") 



allresult=TWAS_fusion_multiprocess(ref_weights_dir = "../FUSION/sCCA_weights_v8/",
                                   LDREF = "../FUSION/LDREF/1000G.EUR",
                                   sumstatsfile = "fuma_PSYCH_factor.sumstats.gz",
                                   outname = "fuma_PSYCH_factor",
                                   tissue = tissues,
                                   startChr = 1,
                                   endChr = 22,
                                   GWASN = GWASN,
                                   coloc_P = 0.05,
                                   nthread = 4)


