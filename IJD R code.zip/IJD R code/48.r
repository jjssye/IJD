
library(Fast2TWAS)
library(Seurat) 
library(celldex)
library(GSVA)
library(GSEABase)
library(harmony)
library(plyr)
library(randomcoloR)
library(ggpubr)
library(ggalluvial)
library(harmony)
library(tidydr)
library(tidyverse)
library(Matrix)
library(stringr)
library(dplyr)
library(patchwork)
library(RColorBrewer)
library(ggrepel)

dir.create("Dimension_Reduction_harmony", showWarnings = FALSE)
dir.create("Clustering", showWarnings = FALSE)
dir.create("Annotation", showWarnings = FALSE)
dir.create("Composition", showWarnings = FALSE)
dir.create("Markers", showWarnings = FALSE)

mmRNA_harmony <- readRDS("harmony_corrected_seurat.rds")


pdf("Dimension_Reduction_harmony/pca_heatmaps.pdf", width = 14, height = 16)
DimHeatmap(mmRNA_harmony, 
           dims = 1:10, 
           nfeatures = 20, 
           cells = 500, 
           balanced = TRUE,
           reduction = "harmony",
           fast = FALSE)
dev.off()


elbow_plot <- ElbowPlot(mmRNA_harmony, ndims = 50, reduction = "harmony") +
  geom_vline(xintercept = 15, linetype = "dashed", color = "red") +
  labs(title = "Harmony PCA Elbow Plot", 
       subtitle = "Variance explained by harmony-corrected principal components",
       caption = "Red line indicates suggested cutoff (PC15)")

ggsave("Dimension_Reduction_harmony/elbow_plot.pdf", plot = elbow_plot, width = 8, height = 6)



ggsave("Dimension_Reduction_harmony/tsne_plot.pdf", 
       plot = DimPlot(mmRNA_harmony, reduction = "tsne") +
         theme_minimal() +
         ggtitle("Harmony-integrated t-SNE Projection"),
       width = 8, height = 6)


ggsave("Dimension_Reduction_harmony/harmony_plot.pdf", 
       plot = DimPlot(mmRNA_harmony, reduction = "harmony") +
         theme_minimal() +
         ggtitle("Harmony Integration Projection"),
       width = 8, height = 6)


distinctColorPalette <- function(n) {
  colors <- colorRampPalette(brewer.pal(9, "Set1"))(n)
  return(colors)
}
group_colors <- distinctColorPalette(length(unique(mmRNA_harmony$orig.ident)))
ggsave("Dimension_Reduction_harmony/group_tsne.pdf", 
       plot = DimPlot(mmRNA_harmony, 
                      reduction = "tsne",
                      group.by = "orig.ident",
                      cols = group_colors) +
         theme_minimal() +
         ggtitle("Group-wise t-SNE Projection (Harmony-integrated") +
         theme(legend.position = "bottom"),
       width = 10, height = 8)


group_colors1 <- distinctColorPalette(length(unique(mmRNA_harmony$group)))
ggsave("Dimension_Reduction_harmony/group_tsne1.pdf", 
       plot = DimPlot(mmRNA_harmony, 
                      reduction = "tsne",
                      group.by = "group",
                      cols = group_colors1) +
         theme_minimal() +
         ggtitle("Group-wise t-SNE Projection (Harmony-integrated") +
         theme(legend.position = "bottom"),
       width = 10, height = 8)



data(cc.genes)
g2m_genes <- intersect(cc.genes$g2m.genes, rownames(mmRNA_harmony))
s_genes <- intersect(cc.genes$s.genes, rownames(mmRNA_harmony))

mmRNA_harmony <- CellCycleScoring(
  object = mmRNA_harmony,
  g2m.features = g2m_genes,
  s.features = s_genes
)


cell_cycle_plot <- mmRNA_harmony@meta.data %>%
  ggplot(aes(S.Score, G2M.Score)) + 
  geom_point(aes(color = Phase), alpha = 0.6) + 
  theme_minimal() +
  scale_color_manual(values = c("#E41A1C", "#377EB8", "#4DAF4A")) +
  labs(title = "细胞周期评分分布", x = "S期评分", y = "G2M期评分")

ggsave("Dimension_Reduction_harmony/cell_cycle_plot.pdf", 
       plot = cell_cycle_plot, width = 6, height = 5)


s_score_plot <- VlnPlot(mmRNA_harmony, features = "S.Score", 
                        group.by = "orig.ident", pt.size = 0.1) +
  theme(legend.position = "none") +
  ggtitle("S期评分")

g2m_score_plot <- VlnPlot(mmRNA_harmony, features = "G2M.Score", 
                          group.by = "orig.ident", pt.size = 0.1) +
  theme(legend.position = "none") +
  ggtitle("G2M期评分")

ggsave("Dimension_Reduction_harmony/cell_cycle_scores_by_sample.pdf", 
       plot = s_score_plot + g2m_score_plot, 
       width = 10, height = 5)


tryCatch({
  mmRNA_harmony <- JackStraw(mmRNA_harmony, num.replicate = 100)
  mmRNA_harmony <- ScoreJackStraw(mmRNA_harmony, dims = 1:20)
  pdf("Dimension_Reduction_harmony/jackstrawplot.pdf", width = 7.5, height = 5.5)
  JackStrawPlot(mmRNA_harmony, dims = 1:20)
  dev.off()
}, error = function(e) {
  cat("JackStraw分析错误:", e$message, "\n")
})


mmRNA_harmony <- FindNeighbors(mmRNA_harmony, dims = 1:10, reduction = "harmony")


resolutions <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0)
for (res in resolutions) {
  mmRNA_harmony <- FindClusters(mmRNA_harmony, resolution = res)
}


p2_tree <- clustree(mmRNA_harmony, prefix = "RNA_snn_res.")
ggsave("Clustering/cluster_tree.pdf", plot = p2_tree, width = 12, height = 10)


mmRNA_harmony <- FindClusters(mmRNA_harmony, resolution = 0.01)#IJD


mmRNA_harmony <- RunUMAP(mmRNA_harmony, dims = 1:10, reduction = "harmony")
mmRNA_harmony <- RunTSNE(mmRNA_harmony, dims = 1:10, reduction = "harmony")


ggsave("Clustering/After_cluster_UMAP.pdf", 
       plot = DimPlot(mmRNA_harmony, reduction = "umap", 
                      label = TRUE, label.size = 4, pt.size = 0.5) + theme_classic(),
       width = 7, height = 6)


ggsave("Clustering/After_cluster_TSNE.pdf", 
       plot = DimPlot(mmRNA_harmony, reduction = "tsne", 
                      label = TRUE, label.size = 4, pt.size = 0.5) + theme_classic(),
       width = 7, height = 6)


mmRNA_harmony.markers <- FindAllMarkers(mmRNA_harmony, only.pos = TRUE, 
                                        min.pct = 0.25, logfc.threshold = 0.25)


top5 <- mmRNA_harmony.markers %>%
  group_by(cluster) %>%
  top_n(n = 5, wt = avg_log2FC)


pdf("Markers/marker_heatmap.pdf", width = 12, height = 9)
DoHeatmap(mmRNA_harmony, features = top5$gene) + 
  theme(text = element_text(size = 8))
dev.off()


write.csv(mmRNA_harmony.markers, "Markers/cluster_markers.csv", row.names = FALSE)


cellpred <- SingleR(test = Stand_data, 
                    ref = SingleRdata, 
                    labels = SingleRdata$label.main,
                    clusters = clusters,
                    assay.type.test = "logcounts", 
                    assay.type.ref = "logcounts")


celltype <- data.frame(ClusterID = rownames(cellpred), 
                       celltype = cellpred$labels, 
                       stringsAsFactors = FALSE)
write.csv(celltype, "Annotation/Auto_anno_SingleR.csv", row.names = FALSE)


pdf("Annotation/singleR_heatmap.pdf", width = 8, height = 7)
plotScoreHeatmap(cellpred, clusters = rownames(cellpred), order.by = "cluster")
dev.off()

mmRNA_harmony <- RenameIdents(mmRNA_harmony, newLabels)


ggsave("Annotation/singleR_UMAP.pdf", 
       plot = DimPlot(mmRNA_harmony, reduction = "umap", 
                      label = TRUE, label.size = 3.5) + theme_classic(),
       width = 7, height = 5.5)


ggsave("Annotation/singleR_TSNE.pdf", 
       plot = DimPlot(mmRNA_harmony, reduction = "tsne", 
                      label = TRUE, label.size = 3.5) + theme_classic(),
       width = 7, height = 5.5)


mmRNA_harmony$Celltype <- Idents(mmRNA_harmony)


cluster_colors <- scales::hue_pal()(length(levels(mmRNA_harmony$seurat_clusters)))
names(cluster_colors) <- levels(mmRNA_harmony$seurat_clusters)

umap_plots <- DimPlot(mmRNA_harmony, 
                      reduction = "umap", 
                      split.by = "orig.ident",
                      group.by = "seurat_clusters",
                      combine = FALSE)

combined_umap <- wrap_plots(umap_plots, ncol = ceiling(sqrt(length(umap_plots))))
ggsave("Composition/umap_integrated_split.pdf", 
       plot = combined_umap, width = 15, height = 10)


df <- mmRNA_harmony@meta.data %>%
  group_by(orig.ident, seurat_clusters) %>%
  summarise(Number = n(), .groups = 'drop') %>%
  group_by(orig.ident) %>%
  mutate(ratio = Number / sum(Number))


ggsave("Composition/celltype_composition.pdf", 
       plot = ggplot(df, aes(x = orig.ident, y = ratio, fill = seurat_clusters)) +
         geom_bar(stat = "identity", position = "fill") +
         scale_fill_manual(values = cluster_colors) +
         labs(x = "Sample", y = "Proportion", fill = "Cluster") +
         theme_minimal() +
         theme(axis.text.x = element_text(angle = 45, hjust = 1)),
       width = 10, height = 6)



ggsave("Composition/gene_violin.pdf", 
       plot = VlnPlot(mmRNA_harmony, features = c("AIF1","IL6R","HLA-DMA","FKBP5","FAM65B","HLA-C"), pt.size = 0),
       width = 10, height = 6)



ggsave("Composition/gene_umap2.pdf", 
       plot = FeaturePlot(mmRNA_harmony, features = c("AIF1","IL6R","HLA-DMA","HLA-C"), reduction = "umap") +
         scale_color_gradientn(colors = c("grey", "blue", "red")),
       width = 8, height = 6)


base_plot <- FeaturePlot(mmRNA_harmony, 
                         features = "ERAP1", 
                         reduction = "umap",
                         pt.size = 0.5) +
  scale_color_gradientn(
    colors = c("grey", "blue", "red"),
    name = "Expression Level"
  ) +
  labs(title = "ERAP1 Expression") +
  theme(legend.position = "right")


ggsave("Composition/gene_umap.pdf", 
       plot = base_plot,
       width = 8, height = 6)



saveRDS(mmRNA_harmony, "After_auto_anno_mmRNA_harmony.rds")







