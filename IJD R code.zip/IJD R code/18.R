
library(Fast2TWAS)
library(data.table)


data=fread("../Gene_disease_association/fuma_PSYCH_factor.fusion_twas.txt")
head(data)

GTEX_V8_gene_id=GTEXv8_ensTOsymble


data$ID=substring(data$ID, 1, 15)

data_single_merge=data.frame(merge(data,GTEX_V8_gene_id,by.x = "ID", by.y = "gene_id",all.x = T)) 
data_single_merge$ensembl=data_single_merge$ID
data_single_merge$ID=data_single_merge$symble

fwrite(data_single_merge,
       file ="fuma_PSYCH_factor.fusion_twas_symble.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)


TWAS_Manhattan_plot(data="fuma_PSYCH_factor.fusion_twas_symble.txt",
                    Sig_Z_Thresh = NULL,
                    Sig_P_Thresh = NULL,
                    savename="STable11_plot")

TWAS_Manhattan_plot(data="fuma_PSYCH_factor.fusion_twas_symble_cleaned.txt",
                    Sig_Z_Thresh = NULL,
                    Sig_P_Thresh = NULL,
                    savename="STable11_plot")




