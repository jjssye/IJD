
library(Fast2TWAS)

trait="IJD"

set.seed(123)

IVW_Wald_ratio_sig=data.table::fread(paste0("../fdr_mendelian_randomization_UKB_PPP/",trait,"_IVW_Wald_ratio_sig_MR_result.txt"))

mr_presso_path="./mr_presso/"
if (!dir.exists(mr_presso_path)) {
  dir.create(mr_presso_path)
}


MR_PRESSO=data.frame()
MR_PRESSO_corrected=data.frame()


for (protein in IVW_Wald_ratio_sig$exposure) {
  i=which(protein == IVW_Wald_ratio_sig$exposure)
  message("\n当前第",i,"个暴露:",protein)
  message("MR-PRESSO：正在执行孟德尔随机化多效性和/或离群值检验")
  message("根据NbDistribution参数和SNPs数量消耗不同时间")
  message("请稍后...")
  dat=data.table::fread(paste0(path,protein,"_",trait,".Mendelian_IVs.txt")) %>% data.frame()
  
  presso <-  try(TwoSampleMR::run_mr_presso(dat,NbDistribution = nrow(dat)/0.05), silent =T)
  
  
  if ("try-error" %in% class(presso)) {
    line=paste0(protein," 筛选后的工具变量不满足mr_presso分析条件，直接跳过该蛋白")
    write(x = line, file = "mr_presso_mendelian_randomization_UKB_PPP.log", append = T)
    message(line)
    next}
  
  
  print(presso)

  
  save(presso,file = paste0(mr_presso_path,protein,"_",trait,"_MR-PRESSO_result.RData"))
  
  
  Raw_corrected <- presso[[1]][["Main MR results"]]
  MR_PRESSO_single=data.frame(
    exposure=protein,
    gene=IVW_Wald_ratio_sig$gene[i],
    method="MR-PRESSO",
    Instruments=paste0(unlist(strsplit(dat[dat$mr_keep==TRUE,]$SNP, "; ")),collapse = ";"),
    nSNPs=length(dat[dat$mr_keep==TRUE,]$SNP),
    beta=Raw_corrected[Raw_corrected$`MR Analysis`=="Raw",]$`Causal Estimate`,
    se=Raw_corrected[Raw_corrected$`MR Analysis`=="Raw",]$`Sd`,
    pval=Raw_corrected[Raw_corrected$`MR Analysis`=="Raw",]$`P-value`)
  MR_PRESSO=rbind(MR_PRESSO_single,MR_PRESSO)
  
  MR_PRESSO_corrected_single=data.frame(
    exposure=protein,
    gene=IVW_Wald_ratio_sig$gene[i],
    method="Outlier-corrected",
    Instruments=paste0(unlist(strsplit(dat[dat$mr_keep==TRUE,]$SNP, "; ")),collapse = ";"),
    nSNPs=length(dat[dat$mr_keep==TRUE,]$SNP),
    beta=Raw_corrected[Raw_corrected$`MR Analysis`=="Outlier-corrected",]$`Causal Estimate`,
    se=Raw_corrected[Raw_corrected$`MR Analysis`=="Outlier-corrected",]$`Sd`,
    pval=Raw_corrected[Raw_corrected$`MR Analysis`=="Outlier-corrected",]$`P-value`)
  MR_PRESSO_corrected=rbind(MR_PRESSO_corrected_single,MR_PRESSO_corrected)

  sig=presso[[1]][["MR-PRESSO results"]][["Global Test"]][["Pvalue"]]

  if(sig<0.05){
    data.table::fwrite(data.frame(SNP=dat[dat$mr_keep==TRUE,]$SNP,
                                  presso[[1]]$`MR-PRESSO results`$`Outlier Test`),
                       file = paste0(mr_presso_path,protein,"_",trait,"_MR-PRESSO.Outlier_test.txt"),
                       row.names = T,
                       sep = "\t")


    
    OutlierSNP=dat[presso[[1]]$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`,]$SNP
    
    message("剔除多效性或离群SNPs：",paste(OutlierSNP,collapse = " "))
    dat=dat[!dat$SNP %in% OutlierSNP,]
  }else{
    message("MR-PRESSO：孟德尔随机化多效性和离群值检验结果：",sig)
    message("不剔除多效性或离群SNPs")
  }

  
  data.table::fwrite(subset(dat, mr_keep),
                     file = paste0(mr_presso_path,protein,"_",trait,"_after_MR-PRESSO_Mendelian_IVs.txt"),
                     sep = "\t")
}


data.table::fwrite(MR_PRESSO,
                   file =paste0(trait,"_MR_PRESSO_MR_result.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(MR_PRESSO_corrected,
                   file =paste0(trait,"_MR_PRESSO_corrected_MR_result.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


