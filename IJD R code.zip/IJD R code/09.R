

library(Fast2TWAS)
library(data.table)
library(corrplot)


index <- fread("../export_index/gwasfile_info.txt")

width=7
height=7


log_file <- list.files(path = "../ld-score_regression/", pattern = ".log",full.names = T)


if (file.exists(log_file)) {
  
  file_content  <- readLines(log_file)
  print(file_content)
  
  
  NSNPs_line <- grep("^Removing", file_content)
  NSNPs_content <- file_content[NSNPs_line]
  
  h2_line <- grep("^Total Observed Scale h2:", file_content)
  h2_content <- file_content[h2_line]
  
  λGC_line <- grep("^Lambda GC:", file_content)
  λGC_content <- file_content[λGC_line]
  
  Chi2_line <- grep("^Mean Chi", file_content)
  Chi2_content <- file_content[Chi2_line]
  
  Intercept_line <- grep("^Intercept: ", file_content)
  Intercept_content <- file_content[Intercept_line]
  
  Ratio_line <- grep("^Ratio: ", file_content)
  Ratio_content <- file_content[Ratio_line]
  
  
  remaining_snps <- as.numeric(gsub(".*;\\s*(\\d+)\\s*remain.*", "\\1", NSNPs_content))
  
  matches <- regmatches(h2_content, gregexpr("h2:\\s*-?\\d+\\.?\\d*(e[+-]?\\d+)?\\s*\\(\\d+\\.?\\d*(e[+-]?\\d+)?\\)", h2_content))
  
  extracted <- sapply(matches, function(x) {
    gsub(".*h2:\\s*(-?\\d+\\.?\\d*(e[+-]?\\d+)?)\\s*\\((\\d+\\.?\\d*(e[+-]?\\d+)?)\\).*", "\\1 \\3", x)
  })
  h2_matches <- do.call(rbind, strsplit(extracted, " "))
 
  λGC_matches <- regmatches(λGC_content, regexec("Lambda GC:\\s*(-?\\d+\\.?\\d*)", λGC_content))
  
  Chi2_matches <- regmatches(Chi2_content, regexec("Mean Chi\\^2 across remaining SNPs:\\s*(-?\\d+\\.?\\d*)", Chi2_content))
  
  Mean_ChiSquare_matches <- sapply(Chi2_matches, function(x) x[2])
  Intercept_matches <- regmatches(Intercept_content, regexec("Intercept:\\s*(-?\\d+\\.?\\d*)\\s*\\((\\d+\\.?\\d*)\\)", Intercept_content))
  
  Intercept_matches <- t(sapply(Intercept_matches, function(x) c(x[2], x[3])))
  
  Ratio_matches <- regmatches(Ratio_content, regexec("Ratio:\\s*(-?\\d+\\.?\\d*)\\s*\\((-?\\d+\\.?\\d*)\\)", Ratio_content))
  
  Ratio_matches <- t(sapply(Ratio_matches, function(x) c(x[2], x[3])))

  
  
  h2_data <- data.frame(Phenotype=index$phenotype,
                        NSNPs=remaining_snps,
                        h2_se=paste0(as.numeric(h2_matches[,1])," (",as.numeric(h2_matches[,2]),")"),
                        λGC=as.numeric(λGC_matches),
                        Mean_ChiSquare=as.numeric(Mean_ChiSquare_matches), #ChiSquare既是Chi^2
                        Intercept_se=paste0(as.numeric(Intercept_matches[,1])," (",as.numeric(Intercept_matches[,2]),")"),
                        Ratio_se=paste0(as.numeric(Ratio_matches[,1])," (",as.numeric(Ratio_matches[,2]),")")       
                        )
  
 
  fwrite(h2_data,
         file = "STable1.txt",
         sep = "\t")
  
  
  rg_line <- grep("^Genetic Correlation between ", file_content)
  rg_content <- file_content[rg_line]
  
  g_cov_line <- grep("^Total Observed Scale Genetic Covariance ", file_content)
  g_cov_content <- file_content[g_cov_line]
  g_cov_p_line <- grep("^g_cov P-value: ", file_content)
  g_cov_p_content <- file_content[g_cov_p_line]
  
  rg_matches <- regmatches(rg_content, regexec(":\\s*(-?\\d+\\.?\\d*)\\s*\\((-?\\d+\\.?\\d*)\\)", rg_content))
  
  rg_matches <- t(sapply(rg_matches, function(x) c(Correlation = x[2], Error = x[3])))
  rg_phen <- do.call(rbind,regmatches(rg_content, gregexpr(paste0(index$phenotype,collapse = "|"), rg_content)))
  
  g_cov_matches <- sub(".*g_cov\\):\\s*(-?\\d+\\.?\\d*(e[+-]?\\d+)?)\\s*\\((\\d+\\.?\\d*(e[+-]?\\d+)?)\\).*", "\\1 \\3", g_cov_content)
  
  rg_data <- data.frame(phen1=rg_phen[,1],
                        phen2=rg_phen[,2],
                        rg_se=paste0(as.numeric(rg_matches[,1])," (",as.numeric(rg_matches[,2]),")"),
                        g_cov_beta_se=paste0(as.numeric(g_cov_matches[,1])," (",as.numeric(g_cov_matches[,2]),")"),
                        g_cov_p=as.numeric(g_cov_p_matches)
                        )
  
 
  fwrite(rg_data,
         file = "rg.txt",
         sep = "\t")
  
  
  rg_data_corr <- data.frame(phen1=rg_phen[,1],
                             phen2=rg_phen[,2],
                             rg=as.numeric(rg_matches[,1]),
                             se=as.numeric(rg_matches[,2]))
  corr <- matrix(data = NA,nrow = length(unique(c(rg_data_corr$phen1,rg_data_corr$phen2))),ncol = length(unique(c(rg_data_corr$phen1,rg_data_corr$phen2))))
  colnames(corr) <- unique(c(rg_data_corr$phen1,rg_data_corr$phen2))
  rownames(corr) <- unique(c(rg_data_corr$phen1,rg_data_corr$phen2))
  for (i in unique(c(rg_data_corr$phen1,rg_data_corr$phen2))) {
    for (j in unique(c(rg_data_corr$phen1,rg_data_corr$phen2))) {
      corr[i,j] <- ifelse(i==j,
                          1,
                          subset(rg_data_corr,phen1==i&phen2==j)$rg
                          )
      if (is.na(corr[i,j])) {
        corr[i,j] <-corr[j,i]
      }
    }
  }
  
  
  data.table::fwrite(data.frame(corr),
                     file = "rg_corr.txt",
                     sep = "\t",
                     row.names = T)

  
  pdf(file = paste0("Fig1a.pdf"), width = width, height = height)
  
  corr <- pmax(pmin(corr, 1), -1)
  corrplot(corr, 
           type = "lower", 
           order = "hclust", 
           tl.col = "black", 
           col=COL2("PuOr", 200), 
  )
  dev.off()
  
  tab <- matrix(data = NA,nrow = length(unique(c(rg_data$phen1,rg_data$phen2))),ncol = length(unique(c(rg_data$phen1,rg_data$phen2))))
  colnames(tab) <- unique(c(rg_data$phen1,rg_data$phen2))
  rownames(tab) <- unique(c(rg_data$phen1,rg_data$phen2))
  
  for (i in unique(c(rg_data$phen1,rg_data$phen2))) {
    for (j in unique(c(rg_data$phen1,rg_data$phen2))) {
      tab[i,j] <- ifelse(i==j,
                         h2_data[h2_data$Phenotype==i,]$h2_se,
                         subset(rg_data,phen1==i&phen2==j)$rg_se)
      if (is.na(tab[i,j])) {
        tab[i,j] <-tab[j,i]
      }
    }
  }
  
 
  data.table::fwrite(data.frame(tab),
                     file = "STable2.txt",
                     sep = "\t",
                     row.names = T)

}


