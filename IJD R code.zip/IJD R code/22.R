
library(Fast2TWAS)
library(data.table)


index_GTEx.ldcts <- fread("../ldsc/tabula_muris.txt",header=F)
index_GTEx.ldcts$V2 <- gsub("tabula_muris/","../ldsc/tabula_muris/",index_GTEx.ldcts$V2)

fwrite(index_GTEx.ldcts,
       file = "tabula_muris.ldcts.txt",
       sep = "\t",
       col.names = F)


ldsc_Cell_type_specific(gwasfile="../result/fuma_PSYCH_factor.sumstats.gz",
                        w_ld_chr = "../ldsc/1000G_Phase3_weights_hm3_no_MHC/weights.hm3_noMHC.",
                        ref_ld_chr = paste0("../ldsc/1000G_Phase3_baselineLD_v2.2_ldscores/baselineLD.",",","../ldsc/control.all_genes_in_dataset/all_genes_in_mousebrain-test."),
                        ref_ld_chr_cts = "tabula_muris.ldcts.txt",
                        flag_options = NULL,
                        outname = "tabula_muris_cell_type_enrichment",
                        force = F) 


LDSC_SEG=fread("result/tabula_muris_cell_type_enrichment.cell_type_results.txt")

LDSC_SEG$FDR=p.adjust(p = LDSC_SEG$Coefficient_P_value, method = "fdr")


fwrite(LDSC_SEG,
       file = "STable14.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)


unlink("tabula_muris.ldcts.txt")



ldcts <- c("GTEx","Multi_tissue_gene_expr","Multi_tissue_chromatin")
for (i in ldcts){
  
  ldsc_Cell_type_specific(gwasfile="../result/fuma_PSYCH_factor.sumstats.gz",
                          w_ld_chr = "../ldsc/1000G_Phase3_weights_hm3_no_MHC/weights.hm3_noMHC.",
                          ref_ld_chr = "../ldsc/1000G_Phase3_baselineLD_v2.2_ldscores/baselineLD.",
                          ref_ld_chr_cts = paste0("../ldsc/",i,".ldcts.txt"),
                          flag_options = NULL,
                          outname = paste0(i,"_enrichment"),
                          force = F) 
  
  
  LDSC_SEG=fread(paste0("result/",i,"_enrichment.cell_type_results.txt"))
  
  LDSC_SEG$FDR=p.adjust(p = LDSC_SEG$Coefficient_P_value, method = "fdr")
  
  
  fwrite(LDSC_SEG,
         file = paste0("STable14_",i,".txt"),
         sep = "\t",
         na = "NA",
         quote = FALSE)
}

