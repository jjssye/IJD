


library(GenomicSEM)
library(Fast2TWAS)


index <- data.table::fread("../gwasfile_info.txt")


gwas_files<-paste0("../calculating_samplesize_with_maf/",index$phenotype,".txt")

hm3<-"../GenomicSEM/w_hm3.noMHC.snplist"


phen<-index$phenotype


N=rep(NA, length(phen))


info.filter=0.9


maf.filter=0.01


parallel = TRUE


cores = ifelse(length(gwas_files)<parallel::detectCores()/2,length(gwas_files),parallel::detectCores()/2)


compiler::loadcmp("../munge.Rc", env = environment())


