
library(Fast2TWAS)
library(data.table)



data=fread("../fuma_PSYCH_factor.fusion_twas_symble_cleaned.txt")
head(data)
dat_focus=fread("../focus_allresult.txt")

dat_focus <- dat_focus[,c("ens_gene_id","eqtlfile","pips_pop1","in_cred_set_pop1")]
dat_focus$eqtlfile=gsub(".db","",dat_focus$eqtlfile)
head(dat_focus)


data_merge=data.frame(merge(data,dat_focus,by.x = c("ensembl","PANEL"), by.y = c("ens_gene_id","eqtlfile"),all.x = T))

colnames(data_merge)[colnames(data_merge) == "pips_pop1"] <- "pip"
colnames(data_merge)[colnames(data_merge) == "in_cred_set_pop1"] <- "in_cred_set"


fwrite(data_merge,
       file ="STable11.txt",
       sep = "\t",
       na = "NA",
       quote = FALSE)

