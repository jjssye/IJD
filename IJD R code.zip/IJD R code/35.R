
library(Fast2TWAS)
options(timeout = 600)

trait="IJD"


wind_size=1000000
type1="quant"         
type2="cc"            
case_pro1=NULL        
case_pro2=0.0163837 
width = 7             
height = 7            


IVW_Wald_ratio_sig=data.table::fread(paste0("../fdr_mendelian_randomization_UKB_PPP/",trait,"_IVW_Wald_ratio_sig_MR_result.txt"))


coloc_path="./result/"
if (!dir.exists(coloc_path)) {
  dir.create(coloc_path)
}


write(x = "", file = "Colocalization_UKB_PPP.log", append = F)
for (i in 1:length(IVW_Wald_ratio_sig$exposure)) {
  gene=IVW_Wald_ratio_sig$gene[i]
  
  message("\n当前第",i,"个基因: ",gene)
  message("当前第",i,"个暴露:",IVW_Wald_ratio_sig$exposure[i])

  dat <- try(coloc_local_gwas2gwas(gwasfile=c(paste0("../reference/ukb_ppp/ukb_ppp_pqtl_cis_1mb_hg38/hg38_ukb_ppp_pqtl_cis_1mb_",IVW_Wald_ratio_sig$exposure[i],".txt"),
                                   metafile),
                        wind_size = wind_size,
                        gene = gene,
                        bfile = "../reference/1000Gv3/EUR",
                        plink_bin = friendlypostGWASsoft::plink_binary(),
                        outfile = paste0(coloc_path,gene,"_",IVW_Wald_ratio_sig$exposure[i],"_",wind_size/1000,"kb.local"),
                        width = width,
                        height = height,
                        build = 38,
                        EUR = "EUR",
                        plot_locuscompare = TRUE,
                        plot_locuscompare_title1="pQTL",
                        plot_locuscompare_title2="GWAS",
                        plot_gassocplot2 = TRUE,
                        type1 = type1,
                        type2 = type2,
                        trait_name1 = gene,
                        trait_name2 = trait,
                        case_pro1 = case_pro1,
                        case_pro2 = case_pro2), silent =T)
  
  
  if ("try-error" %in% class(dat)) {
    line=paste0(IVW_Wald_ratio_sig$exposure[i]," 未能成功与",metafile,"进行共定位，直接跳过")
    message(line)
    write(x = line, file = "Colocalization_UKB_PPP.log", append = T)
    next}

}


all_coloc=data.frame()
for (i in 1:length(IVW_Wald_ratio_sig$exposure)) {
  gene=IVW_Wald_ratio_sig$gene[i]
  message("\n当前第",i,"个基因: ",gene)
  print(IVW_Wald_ratio_sig[i,])
  
  
  data=data.table::fread(paste0("./result/",gene,"_",IVW_Wald_ratio_sig$exposure[i],"_",wind_size/1000,"kb.local.coloc_summary.txt"))
  data$exposure=IVW_Wald_ratio_sig$exposure[i]
  data$gene=gene
  all_coloc=rbind(all_coloc,data)
  
}



data.table::fwrite(all_coloc,
                   file =paste0(trait,"_ukb_ppp_coloc.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)



