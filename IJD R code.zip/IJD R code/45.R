
library(scPagwas)
library(RColorBrewer)
library(Seurat)
library(ggpubr)
library(tidyverse)
library(rhdf5)
library(ggplot2)
library(grDevices)
library(stats)
library(FactoMineR)
library(scales)
library(reshape2)
library(ggdendro)
library(grImport2)
library(gridExtra)
library(grid)
library(sisal)


GWAS_FILE <- "IJD.txt"
SEURAT_FILE <- "After_auto_anno_mmRNA_harmony.rds"
OUTPUT_PREFIX <- "IJD_Analysis"
OUTPUT_DIR <- "scPagwas_results"
N_CORES <- 10
CELLTYPE_ORDER <- c(
  "T_cells",             
  "B_cell",               
  "Monocyte"              
)


scPagwas_result <- scPagwas_main(
  Pagwas = NULL,
  gwas_data = GWAS_FILE,
  Single_data = SEURAT_FILE,
  output.prefix = OUTPUT_PREFIX, 
  output.dirs = OUTPUT_DIR,
  Pathway_list = Genes_by_pathway_kegg,
  n.cores = 1,
  assay = "RNA",
  singlecell = TRUE,
  iters_singlecell = 100,
  celltype = TRUE, 
  block_annotation = block_annotation,
  chrom_ld = chrom_ld
)


save(scPagwas_result, file = "scPagwas_results/scPagwas_final.RData")


load("scPagwas_results/scPagwas_final.RData")


print(scPagwas_result)
names(scPagwas_result)
all_celltypes <- unique(scPagwas_result$Celltype)  
print(all_celltypes)


plot_bar_positie_nagtive(
  seurat_obj = scPagwas_result,
  var_ident = "Celltype",
  var_group = "positiveCells",
  vec_group_colors = c("#E8D0B3", "#7EB5A6"),
  do_plot = TRUE
)


scPagwas_Visualization(
  Single_data = scPagwas_result,
  p_thre = 0.05,
  FigureType = "tsne",
  width = 7,
  height = 7,
  lowColor = "white",
  highColor = "red",
  output.dirs = "figures",
  size = 0.5,
  do_plot = TRUE
)


plot_bar_positie_nagtive(
  seurat_obj = scPagwas_result,
  var_ident = "positiveCells",
  var_group = "Celltype",
  p_thre = 0.01,
  vec_group_colors = NULL,
  f_color = colorRampPalette(brewer.pal(n = 10, name = "RdYlBu")),
  do_plot = TRUE
)


heritability_cor_scatterplot(
  gene_heri_cor = scPagwas_result@misc$PCC,
  topn_genes_label = 10,
  color_low = "#035397",
  color_high = "#F32424",
  color_mid = "white",
  text_size = 2,
  do_plot = TRUE,
  max.overlaps = 20,
  width = 7,
  height = 7
)


Bootstrap_estimate_Plot(
  bootstrap_results = scPagwas_result@misc$bootstrap_results,
  figurenames = "figures/bootstrap_estimate.pdf",
  width = 9,
  height = 7,
  do_plot = TRUE
)



plot_scpathway_dot(
  Pagwas = scPagwas_result,
  Celltype = CELLTYPE_ORDER,
  topn_path_celltype = 5,
  filter_p = 0.05,
  max_logp = 15,
  display_max_sizes = FALSE,
  size_var = "logrankPvalue",
  col_var = "proportion",
  shape.scale = 8,
  cols.use = c("lightgrey", "#E45826"),
  dend_x_var = "logrankPvalue",
  dist_method = "euclidean",
  hclust_method = "ward.D",
  do_plot = TRUE,
  width = 7,
  height = 7
)



