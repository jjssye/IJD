

library(Fast2TWAS)


for (file in index$filename) {
  
  dat <- data.table::fread(paste0("../pre_data/",file),showProgress = F)
  dat_2 <- dat
  
  
  casecontrol <- ifelse(!is.na(index$case[which(file==index$filename)]) & !is.na(index$controls[which(file==index$filename)]),TRUE,FALSE)
  ismeta <- index$ismeta[which(file==index$filename)]
  if (casecontrol & ismeta ) {
    if (!all(is.na(dat$eaf))) {
      
      dat <- dat %>% na.omit()
      dat$MAF <- ifelse(1-dat$eaf>0.5,dat$eaf,1-dat$eaf)
      dat$eaf <- NULL
      dat_ref <- dat
    }else{
      
      dat$eaf <- NULL
      ref<-data.table::fread("../GenomicSEM/reference.1000G.maf.0.005.txt.gz",data.table=FALSE)
      dat_ref <-merge(dat,ref,by="SNP",suffixes = c("", ".y"))
      dat_ref <- subset(dat_ref,select = c(colnames(dat_ref)[which(colnames(dat_ref) %in% colnames(Fast2TWAS::show_demo_gwas()))],"MAF"))
    }
       
      dat_ref$N<-4/((2*dat_ref$MAF*(1-dat_ref$MAF))*dat_ref$se^2)
      
      
      Ncases<-index$case[which(file==index$filename)] 
      Ncontrols<-index$controls[which(file==index$filename)] 
      v<-Ncases/(Ncases+Ncontrols)
      
      TotalNeff<-4*v*(1-v)*(Ncases+Ncontrols)
      
      
      dat_ref$N<-ifelse(dat_ref$N > 1.1*TotalNeff, 1.1*TotalNeff, dat_ref$N)
      
      
      dat_ref$N<-ifelse(dat_ref$N < 0.5*TotalNeff, 0.5*TotalNeff, dat_ref$N)
      
      
      if (all(is.na(dat_2$eaf))) {
        dat_ref$MAF<-NULL
      }
      
  }else{
    
    if (!all(is.na(dat$eaf))) {
      
      dat <- dat %>% na.omit()
      dat$MAF <- ifelse(1-dat$eaf>0.5,dat$eaf,1-dat$eaf)
      dat$eaf <- NULL
      dat_ref <- dat
    }else{
      dat_ref <- dat
    }
  }

  
  data.table::fwrite(dat_ref,
                     file = paste0(index$phenotype[which(file==index$filename)],".txt"),
                     sep = "\t")
  
}


