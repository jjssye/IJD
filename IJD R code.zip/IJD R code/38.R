
library(Fast2TWAS)

trait="IJD"


IVW_method="Fixed"


IVW_Wald_ratio=data.frame()
Simple_mode=data.frame()
Weighted_mode=data.frame()
Weighted_median=data.frame()
MR_Egger=data.frame()
Egger_Intercept=data.frame()
Heterogeneity_Egger=data.frame()
Heterogeneity_IVW=data.frame()


write(x = "", file = "Reverse_fdr_mendelian_randomization_decode.log", append = F)
for (i in 1:length(decode_dat$labels)) {
  protein=decode_dat$labels[i]
  message("\n当前第",i,"个结局: ",protein)
  
  iv_file=paste0(path,trait,"_",protein,".Mendelian_IVs.txt")
  if (file.exists(iv_file)) {
    data1=data.table::fread(iv_file)
  }else if (!file.exists(iv_file)) {
    line=paste0(metafile," 与 ",protein,"进行孟德尔随机化不成功，直接跳过 ",protein)
    write(x = line, file = "Reverse_fdr_mendelian_randomization_decode.log", append = T)
    message(line)
    next}
  
  if (nrow(data1)==1) {
    data2=data.table::fread(paste0(path,trait,"_",protein,"_final_MRresult.txt"))
    mr_data=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Wald ratio",
      Instruments=data1$SNP,
      nSNPs=data2$nsnp,
      b=data2$b,
      se=data2$se,
      pval=data2$pval,
      b_lo_ci=data2$lo_ci,
      b_up_ci=data2$up_ci,
      or=data2$or,
      or_lci95=data2$or_lci95,
      or_uci95=data2$or_uci95
    )
    IVW_Wald_ratio=rbind(mr_data,IVW_Wald_ratio)
  }else if(nrow(data1)==2){
    data2=data.table::fread(paste0(path,trait,"_",protein,"_final_MRresult.txt"))
    
    mr_data=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Inverse variance weighted",
      Instruments=data2[data2$Method=="Inverse variance weighted",]$SNP,
      nSNPs=data2[data2$Method=="Inverse variance weighted",]$nsnp,
      b=data2[data2$Method=="Inverse variance weighted",]$b,
      se=data2[data2$Method=="Inverse variance weighted",]$se,
      pval=data2[data2$Method=="Inverse variance weighted",]$pval,
      b_lo_ci=data2[data2$Method=="Inverse variance weighted",]$lo_ci,
      b_up_ci=data2[data2$Method=="Inverse variance weighted",]$up_ci,
      or=data2[data2$Method=="Inverse variance weighted",]$or,
      or_lci95=data2[data2$Method=="Inverse variance weighted",]$or_lci95,
      or_uci95=data2[data2$Method=="Inverse variance weighted",]$or_uci95)
    IVW_Wald_ratio=rbind(mr_data,IVW_Wald_ratio)
    
    Heterogeneity_IVW_single=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Inverse variance weighted",
      Instruments=data2[data2$Method=="Inverse variance weighted",]$SNP,
      nSNPs=data2[data2$Method=="Inverse variance weighted",]$nsnp,
      Q=data2[data2$Method=="Inverse variance weighted",]$Q,
      Q_df=data2[data2$Method=="Inverse variance weighted",]$Q_df,
      Q_pval=data2[data2$Method=="Inverse variance weighted",]$Q_pval)
    Heterogeneity_IVW=rbind(Heterogeneity_IVW_single,Heterogeneity_IVW)
    
  }else if (nrow(data1)>2){
    data2=data.table::fread(paste0(path,trait,"_",protein,"_final_MRresult.txt"))
    
    mr_data=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Inverse variance weighted",
      Instruments=data2[data2$Method=="Inverse variance weighted",]$SNP,
      nSNPs=data2[data2$Method=="Inverse variance weighted",]$nsnp,
      b=data2[data2$Method=="Inverse variance weighted",]$b,
      se=data2[data2$Method=="Inverse variance weighted",]$se,
      pval=data2[data2$Method=="Inverse variance weighted",]$pval,
      b_lo_ci=data2[data2$Method=="Inverse variance weighted",]$lo_ci,
      b_up_ci=data2[data2$Method=="Inverse variance weighted",]$up_ci,
      or=data2[data2$Method=="Inverse variance weighted",]$or,
      or_lci95=data2[data2$Method=="Inverse variance weighted",]$or_lci95,
      or_uci95=data2[data2$Method=="Inverse variance weighted",]$or_uci95)
    IVW_Wald_ratio=rbind(mr_data,IVW_Wald_ratio)
    
    Heterogeneity_IVW_single=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Inverse variance weighted",
      Instruments=data2[data2$Method=="Inverse variance weighted",]$SNP,
      nSNPs=data2[data2$Method=="Inverse variance weighted",]$nsnp,
      Q=data2[data2$Method=="Inverse variance weighted",]$Q,
      Q_df=data2[data2$Method=="Inverse variance weighted",]$Q_df,
      Q_pval=data2[data2$Method=="Inverse variance weighted",]$Q_pval)
    Heterogeneity_IVW=rbind(Heterogeneity_IVW_single,Heterogeneity_IVW)
    
    
    Egger_data=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="MR Egger",
      Instruments=data2[data2$Method=="MR Egger",]$SNP,
      nSNPs=data2[data2$Method=="MR Egger",]$nsnp,
      b=data2[data2$Method=="MR Egger",]$b,
      se=data2[data2$Method=="MR Egger",]$se,
      pval=data2[data2$Method=="MR Egger",]$pval,
      b_lo_ci=data2[data2$Method=="MR Egger",]$lo_ci,
      b_up_ci=data2[data2$Method=="MR Egger",]$up_ci,
      or=data2[data2$Method=="MR Egger",]$or,
      or_lci95=data2[data2$Method=="MR Egger",]$or_lci95,
      or_uci95=data2[data2$Method=="MR Egger",]$or_uci95)
    MR_Egger=rbind(Egger_data,MR_Egger)
    
    Egger_Intercept_single=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="MR Egger",
      Instruments=data2[data2$Method=="MR Egger",]$SNP,
      nSNPs=data2[data2$Method=="MR Egger",]$nsnp,
      intercept=data2[data2$Method=="MR Egger",]$intercept,
      intercept_se=data2[data2$Method=="MR Egger",]$intercept_se,
      intercept_pval=data2[data2$Method=="MR Egger",]$intercept_pval)
    Egger_Intercept=rbind(Egger_Intercept_single,Egger_Intercept)
    
    Heterogeneity_Egger_single=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="MR Egger",
      Instruments=data2[data2$Method=="MR Egger",]$SNP,
      nSNPs=data2[data2$Method=="MR Egger",]$nsnp,
      Q=data2[data2$Method=="MR Egger",]$Q,
      Q_df=data2[data2$Method=="MR Egger",]$Q_df,
      Q_pval=data2[data2$Method=="MR Egger",]$Q_pval)
    Heterogeneity_Egger=rbind(Heterogeneity_Egger_single,Heterogeneity_Egger)
    
    
    
    Simple=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Simple mode",
      Instruments=data2[data2$Method=="Simple mode",]$SNP,
      nSNPs=data2[data2$Method=="Simple mode",]$nsnp,
      b=data2[data2$Method=="Simple mode",]$b,
      se=data2[data2$Method=="Simple mode",]$se,
      pval=data2[data2$Method=="Simple mode",]$pval,
      b_lo_ci=data2[data2$Method=="Simple mode",]$lo_ci,
      b_up_ci=data2[data2$Method=="Simple mode",]$up_ci,
      or=data2[data2$Method=="Simple mode",]$or,
      or_lci95=data2[data2$Method=="Simple mode",]$or_lci95,
      or_uci95=data2[data2$Method=="Simple mode",]$or_uci95)
    Simple_mode=rbind(Simple,Simple_mode)
    
    
    Weighted_mode_single=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Weighted mode",
      Instruments=data2[data2$Method=="Weighted mode",]$SNP,
      nSNPs=data2[data2$Method=="Weighted mode",]$nsnp,
      b=data2[data2$Method=="Weighted mode",]$b,
      se=data2[data2$Method=="Weighted mode",]$se,
      pval=data2[data2$Method=="Weighted mode",]$pval,
      b_lo_ci=data2[data2$Method=="Weighted mode",]$lo_ci,
      b_up_ci=data2[data2$Method=="Weighted mode",]$up_ci,
      or=data2[data2$Method=="Weighted mode",]$or,
      or_lci95=data2[data2$Method=="Weighted mode",]$or_lci95,
      or_uci95=data2[data2$Method=="Weighted mode",]$or_uci95)
    Weighted_mode=rbind(Weighted_mode_single,Weighted_mode)
    
    
    Weighted_median_single=data.frame(
      outcome=protein,
      gene=gsub("_","-",decode_dat$gene_name_Ensembl[i]),
      method="Weighted median",
      Instruments=data2[data2$Method=="Weighted median",]$SNP,
      nSNPs=data2[data2$Method=="Weighted median",]$nsnp,
      b=data2[data2$Method=="Weighted median",]$b,
      se=data2[data2$Method=="Weighted median",]$se,
      pval=data2[data2$Method=="Weighted median",]$pval,
      b_lo_ci=data2[data2$Method=="Weighted median",]$lo_ci,
      b_up_ci=data2[data2$Method=="Weighted median",]$up_ci,
      or=data2[data2$Method=="Weighted median",]$or,
      or_lci95=data2[data2$Method=="Weighted median",]$or_lci95,
      or_uci95=data2[data2$Method=="Weighted median",]$or_uci95)
    Weighted_median=rbind(Weighted_median_single,Weighted_median)
  } else if (nrow(data1)==0){
    line=paste0(protein," 未能成功与",metafile,"进行孟德尔随机化，直接跳过")
    write(x = line, file = "Reverse_fdr_mendelian_randomization_decode.log", append = T)
    message(line)
  }
}  



data.table::fwrite(IVW_Wald_ratio,
                   file =paste0(trait,"_IVW_Wald_ratio_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(IVW_Wald_ratio_sig,
                   file =paste0(trait,"_IVW_Wald_ratio_sig_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(Simple_mode,
                   file =paste0(trait,"_Simple_mode_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(Weighted_mode,
                   file =paste0(trait,"_Weighted_mode_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(Weighted_median,
                   file =paste0(trait,"_Weighted_median_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(MR_Egger,
                   file =paste0(trait,"_MR_Egger_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(Egger_Intercept,
                   file =paste0(trait,"_Egger_Intercept_MR_result_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(Heterogeneity_Egger,
                   file =paste0(trait,"_Heterogeneity_Egger_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)

data.table::fwrite(Heterogeneity_IVW,
                   file =paste0(trait,"_Heterogeneity_IVW_reverse.txt"),
                   sep = "\t",
                   na = "NA",
                   quote = FALSE)


