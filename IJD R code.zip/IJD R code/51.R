

library(dplyr)
library(clusterProfiler)
library(org.Hs.eg.db)
 


data <- read.csv("IL6R_KO_diffRegulation.csv")

data <- read.csv("AIF1_KO_diffRegulation.csv")

data <- read.csv("AIF1_IL6R_KO_diffRegulation.csv")


target_ko_gene <- "IL6R"

target_ko_gene <- "AIF1" 

target_ko_gene <- c("AIF1", "IL6R")


sig_genes <- data %>% 
  filter(p.adj < 0.05 & gene != target_ko_gene) %>% 
  pull(gene)

print("正在进行 GO (BP, CC, MF) 全面富集分析...")

go_res <- enrichGO(
  gene          = sig_genes,
  OrgDb         = org.Hs.eg.db,
  keyType       = "SYMBOL",
  ont           = "ALL",  
  pvalueCutoff  = 0.05
)
go_df <- as.data.frame(go_res)


top_go <- go_df %>% 
  group_by(ONTOLOGY) %>% 
  slice_head(n = 3) %>% 
  ungroup() %>%
  dplyr::select(Category = ONTOLOGY, Pathway = Description, geneID)

print("正在进行基因 ID 转换与 KEGG 富集分析...")

gene_ids <- bitr(sig_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
kegg_res <- enrichKEGG(
  gene          = gene_ids$ENTREZID,
  organism      = 'hsa',    
  pvalueCutoff  = 0.05
)

top_kegg <- data.frame(Category=character(), Pathway=character(), geneID=character())
if (!is.null(kegg_res) && nrow(kegg_res) > 0) {
  kegg_res <- setReadable(kegg_res, OrgDb = org.Hs.eg.db, keyType="ENTREZID")
  kegg_df <- as.data.frame(kegg_res)
  
  top_kegg <- kegg_df %>% 
    slice_head(n = 3) %>% 
    mutate(Category = "KEGG") %>%
    
    dplyr::select(Category, Pathway = Description, geneID) 
}



edge_list <- data.frame(Pathway = character(), Gene = character(), Category = character(), stringsAsFactors = FALSE)
for(i in 1:nrow(all_pathways)) {
  genes_in_pathway <- unlist(strsplit(all_pathways$geneID[i], "/"))
  temp_df <- data.frame(
    Pathway = all_pathways$Pathway[i],
    Gene = genes_in_pathway,
    Category = all_pathways$Category[i]
  )
  edge_list <- rbind(edge_list, temp_df)
}


category_colors <- c("BP" = "#E64B35", "CC" = "#4DBBD5", "MF" = "#00A087", "KEGG" = "#3C5488")

grid.col <- setNames(rep("grey80", length(unique(edge_list$Gene))), unique(edge_list$Gene))
for(path in unique(edge_list$Pathway)){
  cat <- unique(edge_list$Category[edge_list$Pathway == path])
  grid.col[path] <- category_colors[cat]
}


pdf("Perfect_Chord_Diagram.pdf", width = 14, height = 14) 

circos.clear()

circos.par(gap.degree = 1.5) 

chordDiagram(
  edge_list[, c("Pathway", "Gene")],
  transparency = 0.5,
  annotationTrack = "grid", 
  
  preAllocateTracks = list(track.height = 0.3) 
)


circos.track(track.index = 1, panel.fun = function(x, y) {
  sector.index = get.cell.meta.data("sector.index")
  xcenter = get.cell.meta.data("xcenter")
  ylim = get.cell.meta.data("ylim")
  
  text_col <- ifelse(sector.index %in% edge_list$Pathway, grid.col[sector.index], "black")
  
  circos.text(xcenter, ylim[1], sector.index, 
              facing = "clockwise", niceFacing = TRUE, adj = c(0, 0.5),
              cex = 0.85, font = 2, col = text_col)
}, bg.border = NA)


legend("topright", 
       legend = names(category_colors), 
       fill = category_colors, 
       border = NA,
       title = "Pathway Categories",
       cex = 1.2, 
       box.col = "white")

title("Comprehensive GO & KEGG Enrichment Chord Diagram", cex.main = 1.8, line = -2)

dev.off()
circos.clear()



