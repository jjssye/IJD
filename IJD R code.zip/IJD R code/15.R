
library(echolocatoR)
library(data.table)
library(tidyverse)
library(Fast2TWAS)


dataset_name = "echolocatoR_result"

fullSS_genome_build = "hg19"

bp_distance = 250000

finemap_methods = c("SUSIE","FINEMAP")

nThread = 4


topSS <- fread("STable6.txt")
head(topSS)

colmap <- echodata::construct_colmap(
  munged = FALSE,
  CHR = "CHR",
  POS = "BP",
  SNP = "rsID",
  P = "P",
  Effect = "beta",
  StdErr = "se",
  # tstat = "tstat",
  Locus = "nearestGene",
  # Freq = "Freq",
  MAF = "MAF",
  A1 = "effect_allele",
  A2 = "non_effect_allele",
  # Gene = "Gene",
  N_cases = "N_cases",
  N_controls = "N_controls",
  proportion_cases = "calculate",
  N = "N",
  verbose = TRUE
)


topSNPs <- echodata::import_topSNPs(
  topSS = topSS,
  colmap = colmap,
)

head(topSNPs)


fullSS_path <- "fuma_PSYCH_factor.txt"
NEW_fullSS_path <- "NEW_fuma_PSYCH_factor.txt"
data <- fread(fullSS_path)%>%
  rename(
    MAF = eaf,
    A1 = effect_allele,
    A2 = other_allele,
    BETA = beta,
    SE = se,
    P = pval,
  )%>%
  mutate(
    N = as.integer(N) 
  )

head(data)

fwrite(data,file = NEW_fullSS_path,sep = "\t")


loci=topSNPs$Locus


compiler::loadcmp("SuSIE_and_FINEMAP.Rc", env = environment())


save.image(file = "echolocatoR_result.RData")

fwrite(results[["merged_dat"]],
       file = "echolocatoR_result.txt",
       sep = "\t")

