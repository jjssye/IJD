
library(tidyverse)
library(Fast2TWAS)
library(data.table)


dat_leadSNPs <- fread("../lead_snp_annot/pre_STable6.txt")
merge_data <- dat_leadSNPs[, c("Novel","GenomicLocus", "rsID", "CHR", "BP", "nearestGene", "non_effect_allele", "effect_allele", "MAF","beta","se", "p")]
merge_data$Novel <- as.character(merge_data$Novel)
merge_data$Novel <- ""

for (file in index$filename) {
  dat_gwas <- fread(paste0("../pre_data/",file))
  
  dat_gwas_leadSNPs <- dat_gwas[dat_gwas$SNP %in% dat_leadSNPs$rsID ,]
  
  colnames(dat_gwas_leadSNPs) <- paste0(colnames(dat_gwas_leadSNPs) ,"_",index$phenotype[which(file == index$filename)])
  
  fwrite(dat_gwas_leadSNPs,
         file = paste0("leadSNP_",index$phenotype[which(file == index$filename)],".txt"),
         sep = "\t")
 
  p_col <- paste0("pval_",index$phenotype[which(file == index$filename)])
  index_logi <- merge_data %>% select(all_of(p_col))<5e-8
  for (i in 1:length(index_logi)) {
    if (index_logi[i]) {
      merge_data[i,]$Novel=paste(merge_data[i,]$Novel,paste0("No_",index$phenotype[which(file == index$filename)]),sep = ",")
    }
  }
}



for (i in 1:length(index_logi)) {
  merge_data[i,]$Novel <- sub("^,", "", merge_data[i,]$Novel )
  if (merge_data[i,]$Novel=="") {
    merge_data[i,]$Novel="YES"
  }
}


dat_leadSNPs$Novel <- merge_data$Novel


fwrite(dat_leadSNPs,
       file = "STable6.txt",
       sep = "\t")


fwrite(merge_data,
       file = "STable7.txt",
       sep = "\t")


